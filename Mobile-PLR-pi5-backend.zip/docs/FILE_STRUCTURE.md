# File structure and what each file does

This is the map of the repository after the Raspberry Pi 5 rebuild. For the
step-by-step setup order, see the main [`README.md`](../README.md).

## 1. Overview

```text
Mobile-PLR/
├── README.md                    Step-by-step setup and daily use (start here)
├── TESTING.md                   How to test without and with hardware
├── .gitignore                   Keeps venv, builds, sessions and device settings out of git
├── docs/
│   └── FILE_STRUCTURE.md        This file
│
├── backend/                     Everything that runs on the Raspberry Pi 5
│   ├── server.py                Entry point: HTTP server + starts all hardware
│   ├── README.md                Backend reference: wiring, API, settings, models
│   ├── requirements.txt         Python packages for the Pi
│   ├── requirements-models.txt  Optional ResNet-18 runtimes (ONNX / TFLite)
│   │
│   ├── plr/                     The orchestrator package (Python)
│   │   ├── __init__.py          Package marker + version number
│   │   ├── settings.py          Persistent device settings + pin-clash checks
│   │   ├── timebase.py          Kernel clocks, RTC and NTP status
│   │   ├── leds.py              Left/right WS2812 driver, power x intensity
│   │   ├── endstops.py          Optical flash detection (kernel-timestamped edges)
│   │   ├── camera_service.py    Always-on IR camera, recording, frame timestamps
│   │   ├── display.py           TFT live preview (replaces ir_display.py)
│   │   ├── config_adapter.py    App request -> session config (old + new formats)
│   │   ├── orchestrator.py      Runs one session: flashes + recording + timeline
│   │   │
│   │   ├── analysis/            Post-recording analysis (runs in its own process)
│   │   │   ├── __init__.py
│   │   │   ├── worker.py        Starts the low-priority analysis process
│   │   │   ├── pipeline.py      Crop eyes -> analyzer -> pupilogram + metrics
│   │   │   ├── eye_cropper.py   Fixed-scale, frame-aligned eye crops
│   │   │   └── plr_metrics.py   Baseline, latency, MCA, MCV formulas
│   │   │
│   │   └── analyzers/           Swappable pupil models
│   │       ├── __init__.py      Registry: lists, loads and creates analyzers
│   │       ├── base.py          The contract every model implements
│   │       ├── purest.py        PuReST / PuRe (native C++) + old binary
│   │       ├── resnet18.py      ResNet-18 from ml_model/ (TFLite or ONNX)
│   │       ├── command.py       Any external program as a model
│   │       └── plugins/
│   │           └── example_threshold.py   Template for your own Python model
│   │
│   ├── native/purest/           C++ PuReST runner
│   │   ├── CMakeLists.txt       Build recipe
│   │   ├── src/purest_cli.cpp   Command-line runner: eye video -> CSV
│   │   └── third_party/pupil-detection-methods/
│   │       ├── PuRe.h / PuRe.cpp                     PuRe detector
│   │       ├── PuReST.h / PuReST.cpp                 PuReST tracker
│   │       ├── Pupil.h                               Pupil ellipse type
│   │       ├── PupilDetectionMethod.h / .cpp         Shared base class
│   │       └── License_PuRe.txt / License_PuReST.txt Non-commercial licence
│   │
│   ├── scripts/                 Installation and system services
│   │   ├── install_pi5.sh       One-shot installer (safe to re-run)
│   │   ├── build_native.sh      Builds the PuReST runner
│   │   ├── rtc_sync.sh          Syncs system clock <-> external RTC
│   │   ├── plr.service          systemd unit: the always-on server
│   │   ├── plr-rtc.service      systemd unit: one RTC sync
│   │   └── plr-rtc.timer        systemd timer: RTC sync at boot + hourly
│   │
│   ├── tools/
│   │   └── flash_timer.py       Stand-alone endstop timing test
│   └── tests/
│       └── test_core.py         Hardware-free unit tests (pytest)
│
├── ml_model/                    ResNet-18 model (unchanged by the rebuild)
│   ├── inference/               Inference code + weights used by resnet18.py
│   └── train/                   Training script, sample clips, checkpoints
│
└── mobile/                      Eyezer React Native app (unchanged)
    ├── App.js, index.js         App entry and navigation
    ├── api.js                   Talks to the Pi (/session, /status, /results)
    ├── screens/                 Home, Details, Config, Experiment, Results, Dashboard
    ├── android/, ios/           Native projects
    └── build_windows.ps1        Windows Android build helper
```

### Created at runtime (not in git)

```text
Mobile-PLR/
├── .venv/                               Python environment (installer)
├── device_settings.json                 Your saved settings (POST /settings)
├── backend/native/purest/build/
│   └── plr_purest                       Compiled PuReST runner (installer)
└── sessions/
    └── 20261002_174352_037495_Name/     One folder per session
        ├── full_video.mp4               Recording
        ├── frames.csv                   Frame -> sensor timestamp -> time_s
        ├── endstop_edges.csv            Raw optical edges from both sensors
        ├── events.json                  Flash timeline, latency, crosstalk, warnings
        ├── pupilogram.json              Per-frame pupil diameters (both eyes)
        ├── metrics.json                 Per-flash MCA, MCV, latency (direct + consensual)
        ├── pupilogram_<model>.json      Extra results from re-analysis
        ├── metrics_<model>.json
        ├── manifest.json                Request, settings, hardware + clock snapshot
        └── session.log                  Diagnostics
```

## 2. How the files work together

```text
 Phone app (mobile/api.js)
     │  POST /session
     ▼
 server.py ── config_adapter.py ──► session config
     │
     ├── orchestrator.py
     │     ├── leds.py ............ WS2812 on GPIO18 / GPIO13
     │     ├── endstops.py ........ optical edges on GPIO17 / GPIO27
     │     └── camera_service.py .. full_video.mp4 + frames.csv
     │          → events.json (measured flash onsets matched to frames)
     │
     ├── analysis/worker.py  (separate low-priority process)
     │     └── pipeline.py
     │           ├── eye_cropper.py ......... left/right eye videos
     │           ├── analyzers/<model>.py ... per-frame pupil diameter
     │           │     └── native/purest/build/plr_purest (for purest/pure)
     │           └── plr_metrics.py ......... MCA, MCV, latency
     │           → pupilogram.json + metrics.json
     │
     └── GET /results ──► phone app shows the pupilogram and metrics

 Always running in the background, independent of sessions:
   camera_service.py ─► lores frames ─► display.py (TFT) and /stream.mjpg
   timebase.py + scripts/rtc_sync.sh ─► correct date/time for session names
```

## 3. File-by-file reference

### Repository root

| File | Function |
|---|---|
| `README.md` | Ordered setup instructions, turning off the old IR display, daily use, updating, troubleshooting. |
| `TESTING.md` | Unit tests, mock-hardware run, and on-rig hardware checks. |
| `.gitignore` | Excludes `.venv/`, `sessions/`, `device_settings.json`, the C++ build folder and caches, so `git pull` never conflicts with data on the Pi. |
| `docs/FILE_STRUCTURE.md` | This document. |

### `backend/` top level

| File | Function | Edit it when… |
|---|---|---|
| `server.py` | Starts everything at boot (LEDs, endstops, camera, TFT, analyzer registry) and serves the HTTP API on port 5000. Holds the session state the app polls, guards against overlapping sessions, launches analysis, and handles `/settings`, `/selftest`, `/leds/test`, `/stream.mjpg`, `/sessions/.../reanalyze`, `/restart`. | You add a new API endpoint. |
| `README.md` | Backend reference: wiring table, safety notes, session flow, settings keys, model swapping, troubleshooting. | |
| `requirements.txt` | Python packages: Flask, NumPy (<2), OpenCV (<4.12), pandas, Pillow, luma.lcd + rpi-lgpio (TFT), Adafruit Blinka + Pi 5 NeoPixel (WS2812). | You need a new Python dependency. |
| `requirements-models.txt` | onnxruntime and tflite-runtime for ResNet-18. Installed separately so a failure here never blocks PuReST. | |

### `backend/plr/` – orchestrator package

| File | Function | Key details |
|---|---|---|
| `__init__.py` | Marks the package and holds `__version__` (2.0.0), reported by `/health`. | |
| `settings.py` | Defaults for every rig setting. Loads and saves `device_settings.json`, merges partial updates, and validates them. | Rejects GPIO clashes (e.g. an LED on the TFT's DC pin, anything on SPI0 or I2C), out-of-range power, odd camera sizes. Default pins: LEDs 18/13, endstops 17/27, TFT DC 24 / RST 25. |
| `timebase.py` | Everything about time. Samples kernel clocks together (`anchor`), detects which clock a timestamp uses, converts to CLOCK_MONOTONIC, reads RTCs from `/sys/class/rtc`, checks NTP, and picks the best wall-clock time for naming sessions. | Measurement timing never uses wall-clock time; the RTC/NTP only date the sessions. |
| `leds.py` | Drives the two independent WS2812s through the Pi 5 PIO block (`adafruit_raspberry_pi5_neopixel_write`). Converts colour × power % × intensity % × channel gain into bytes in the LED's colour order. Thread-safe; both LEDs change within microseconds in dual mode. Includes a mock backend. | `LedConfig.scaled_rgb()` is the brightness formula. `set()` returns command timestamps (diagnostic only). |
| `endstops.py` | Claims GPIO17/27 with lgpio alerts so the kernel timestamps every edge. Auto-detects polarity (idle level with LEDs off), merges WS2812 PWM bursts into single flashes, warns if a sensor reads active in the dark. Includes an optical simulator for mock mode. | `pulses(side, start, end)` returns merged flashes. |
| `camera_service.py` | Opens Picamera2 once at boot and never closes it. Main stream (640×480) is H.264-encoded only while recording; lores stream (320×240, Y plane) is copied at ~15 fps for the TFT and HTTP preview. Logs each encoded frame's SensorTimestamp. Watchdog reopens the camera if frames stop (only when idle) and retries forever if it's missing at boot. `MockCameraService` renders synthetic IR eyes that react to the LEDs. | `begin_recording()` / `end_recording()` return the frame timestamps. |
| `display.py` | Shows the lores stream on the ST7789 TFT (SPI0, DC=24, RST=25) via luma.lcd, with an overlay: stage, REC dot, lit-LED markers, clock + source (NTP/RTC), the Pi's IP:port, and a centre line for aligning the eyes. Retries with back-off if the display fails; never blocks the camera. | Replaces `ir_display.py` + `ir-display.service` from the led-test repo. |
| `config_adapter.py` | Converts the app's JSON into a session config. Accepts the current app format, the older single-eye format, and new optional fields (`leds.left/right.power/intensity`, `leftIntensity`/`rightIntensity`, `observe` mode). Enforces the minimum gap and picks the analyzer (forced > requested > default). | Change here if the app's request format changes. |
| `orchestrator.py` | `SessionRecorder` runs one session: starts recording, runs the dual or sequential schedule with precise sleeps, switches LEDs off on any error, stops recording, then matches every LED command to its optical pulse and to video frames. Writes `events.json`, `frames.csv`, `endstop_edges.csv`. Detects crosstalk and missing flashes. | `_build_timeline()` is where measured onsets become `onset_s` / `onset_frame`. |

### `backend/plr/analysis/` – analysis

| File | Function |
|---|---|
| `worker.py` | Runs the analysis in a separate process (spawn, never fork, because the parent owns the camera), lowered priority (`nice`) and pinned to CPU cores 2–3, so the camera, TFT and server stay smooth. Streams progress back to `/status`. |
| `pipeline.py` | For each eye: crop → run the chosen analyzer → assign each sample its real time from `frames.csv` → compute metrics in a window around every measured flash onset (direct and consensual). Writes `pupilogram.json` and `metrics.json` in the shape the app already reads. |
| `eye_cropper.py` | From the previous fork. Two-pass cropping: finds the eye (Haar cascade, `detect` mode) or uses a fixed region (`static` mode), then writes one constant-scale crop per source frame so frame numbers and pupil scale stay aligned. |
| `plr_metrics.py` | From the previous fork, extended to accept measured frame times. Computes baseline diameter, constriction onset/latency, minimum diameter, MCA (px and %), MCV, constriction time; also PIPR metrics. |

### `backend/plr/analyzers/` – swappable models

| File | Function |
|---|---|
| `__init__.py` | Registry. `load_all()` registers the built-ins, imports every file in `plugins/`, and adds external commands from the settings. `create()` builds a model for one eye; `status_all()` powers `/analyzers`. |
| `base.py` | The contract: `analyze(video) → DataFrame[frame, diameter_px, confidence, valid]`. Also `validate_trace()` (fills missing frames, enforces types) and `read_trace_csv()` (reads generic or PuReST-style CSVs). |
| `purest.py` | `purest` and `pure`: call `native/purest/build/plr_purest` with explicit paths and report progress. `purest_legacy`: the old fixed-path `~/pupil_detection_new` binary, kept for comparison. |
| `resnet18.py` | Loads `ml_model/inference/inference_{tflite,onnx}.py` and the left/right weights; prefers TFLite, falls back to ONNX. Readiness check catches missing runtimes before a session starts. |
| `command.py` | Wraps any external program (other language or venv) as a model, using `{input}`, `{output}` and `{eye}` placeholders. |
| `plugins/example_threshold.py` | Template plugin (`dark_blob`): threshold + largest dark contour. Copy it to add your own model. |

### `backend/native/purest/` – C++

| File | Function |
|---|---|
| `CMakeLists.txt` | Builds the algorithm library and `plr_purest` against system OpenCV; uses `-mcpu=native` on the Pi 5. |
| `src/purest_cli.cpp` | Reads an eye video frame by frame, runs PuReST (or PuRe), writes `Frame,Valid,Confidence,Outline_confidence,Diameter_px,Minor_px,Center_x,Center_y,Angle_deg`. Writes to `.partial` and renames at the end so a crash never leaves a half file. Options: `--algorithm`, `--min-pupil-mm`, `--max-pupil-mm`, `--progress`. |
| `third_party/pupil-detection-methods/*` | PuRe/PuReST source by Thiago Santini et al. (via PyPupilEXT, commit a2999de), unmodified apart from line endings. Non-commercial licence; keep the licence files. |

### `backend/scripts/` – installation and services

| File | Function |
|---|---|
| `install_pi5.sh` | The installer, in order: platform check → APT packages → SPI/I2C/RTC lines in `config.txt` → `.venv` + requirements (swaps RPi.GPIO for rpi-lgpio) → builds PuReST → adds the user to video/gpio/spi/i2c and a `/dev/pio0` udev rule → disables `ir-display.service` → installs and enables `plr.service` and the RTC timer. Variable `RTC_MODEL=ds1307|ds3231|none`. |
| `build_native.sh` | Configures and compiles `plr_purest`. Run alone after editing the C++. |
| `rtc_sync.sh` | Finds the external RTC (ignores the Pi 5's own). With NTP: writes system time into the RTC. Without NTP and with an unset clock: sets system time from the RTC. |
| `plr.service` | Runs `server.py` from `.venv` at boot as your user, `Restart=always`, slight priority boost for the camera. `@USER@`/`@REPO@` are filled in by the installer. |
| `plr-rtc.service` / `plr-rtc.timer` | Run `rtc_sync.sh` as root at boot and every hour. |

### `backend/tools/` and `backend/tests/`

| File | Function |
|---|---|
| `tools/flash_timer.py` | Stand-alone endstop test: logs kernel-timestamped flashes and widths from one GPIO. Stop `plr.service` first (it owns the pins), or use `POST /selftest` instead. |
| `tests/test_core.py` | 21 hardware-free tests: settings validation and pin clashes, every app request format, brightness formula, WS2812 byte order, PWM burst merging, optical-vs-command matching, and metrics with dropped frames. Run with `python -m pytest tests -q`. |

## 4. Which file do I change for…?

| I want to… | Change |
|---|---|
| Move an LED, endstop or TFT pin | `POST /settings` (no code). Defaults: `plr/settings.py` |
| Balance the two LEDs | `leds.left/right.power_pct` via `POST /settings` |
| Fix camera exposure or flip the image | `camera.controls`, `camera.hflip/vflip` via `POST /settings` |
| Use a different pupil model | App choice, `analysis.force_analyzer`, or a new file in `plr/analyzers/plugins/` |
| Change MCA/MCV/latency formulas | `plr/analysis/plr_metrics.py` |
| Change how eyes are cropped | `eye_crop` settings; logic in `plr/analysis/eye_cropper.py` |
| Change the TFT overlay | `plr/display.py` (`_draw_overlay`) |
| Add a flash mode | `plr/config_adapter.py` (request) + `plr/orchestrator.py` (schedule) |
| Add an API endpoint | `server.py` |
| Change the app's server address default | `mobile/api.js` (`DEFAULT_PI_BASE_URL`); usually just type it in the app |

## 5. Files removed from the previous fork

| Old file | Replaced by |
|---|---|
| `backend/led_controller.py` (pigpio, RGB LEDs) | `plr/leds.py` (WS2812, Pi 5 PIO) + `plr/endstops.py` |
| `backend/camera_service.py`, `camera_controller.py` | `plr/camera_service.py` |
| `backend/orchestrator.py` | `plr/orchestrator.py` |
| `backend/config_adapter.py` | `plr/config_adapter.py` |
| `backend/purest_caller.py` | `plr/analysis/pipeline.py` + `plr/analyzers/purest.py` |
| `backend/model_caller.py` | `plr/analyzers/resnet18.py` |
| `backend/pupil_analyzer.py` | `plr/analyzers/base.py` |
| `backend/main.py`, `config_wizard.py` | `server.py` + curl (see README) |
| `backend/collect_diagnostics.sh` | `GET /health`, `session.log`, `manifest.json` |
| `backend/INTEGRATION.md`, old tests | `backend/README.md`, `tests/test_core.py` |
| led-test repo `ir_display.py`, `ir-display.service` | `plr/display.py` inside `plr.service` |

They remain in the git history if you ever need them.
