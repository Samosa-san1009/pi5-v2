"""Example plugin: a tiny dark-blob pupil estimator.

Files in this folder are loaded automatically at start-up. A plugin defines a
PupilAnalyzer subclass and a register_analyzers(register) function. Then pick
it from the app (pupilAnalyzer), or with analysis.force_analyzer.

This one is deliberately simple (threshold + largest dark contour) and is
mainly a template; it is fine for checking that the pipeline works.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from plr.analyzers.base import PupilAnalyzer, validate_trace


class DarkBlobAnalyzer(PupilAnalyzer):
    name = "dark_blob"

    def analyze(self, video_path: str, progress=None) -> pd.DataFrame:
        import cv2

        cap = cv2.VideoCapture(str(video_path))
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or None
        rows = []
        index = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            grey = cv2.GaussianBlur(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (7, 7), 0)
            # Pupil = darkest region: threshold halfway between the darkest
            # pixels and the typical (median) brightness of the eye crop.
            threshold = (np.percentile(grey, 0.5) + np.median(grey)) / 2.0
            _, mask = cv2.threshold(grey, threshold, 255, cv2.THRESH_BINARY_INV)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            diameter = np.nan
            if contours:
                largest = max(contours, key=cv2.contourArea)
                if cv2.contourArea(largest) > 20:
                    diameter = 2.0 * np.sqrt(cv2.contourArea(largest) / np.pi)
            rows.append((index, diameter, 1.0 if np.isfinite(diameter) else 0.0, bool(np.isfinite(diameter))))
            index += 1
            if progress and total and index % 100 == 0:
                progress(index / total)
        cap.release()
        return validate_trace(pd.DataFrame(rows, columns=["frame", "diameter_px", "confidence", "valid"]), total)


def register_analyzers(register):
    register("dark_blob", DarkBlobAnalyzer, description="Example plugin: threshold + largest dark blob", source="plugin")
