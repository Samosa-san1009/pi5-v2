"""Analyzer registry.

Built-in analyzers:
  purest         PuReST built from backend/native/purest (default)
  pure           PuRe without tracking (same binary, per-frame detection)
  purest_legacy  the old fixed-path ~/pupil_detection_new PupilDetection binary
  resnet18       ResNet-18 TFLite/ONNX models from ml_model/

Add your own, without touching the server:
  1. drop a .py file in backend/plr/analyzers/plugins/ that subclasses
     PupilAnalyzer and calls register() (see plugins/example_threshold.py), or
  2. register an external program under analysis.commands in the device
     settings (see command.py).

Pick one per session from the app (pupilAnalyzer), set a default with
analysis.default_analyzer, or force one with analysis.force_analyzer.
"""

from __future__ import annotations

import importlib
import importlib.util
import sys
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from .base import AnalyzerError, PupilAnalyzer, read_trace_csv, validate_trace

__all__ = ["AnalyzerError", "PupilAnalyzer", "validate_trace", "read_trace_csv",
           "register", "registry", "create", "status_all", "load_all"]


@dataclass
class AnalyzerEntry:
    name: str
    factory: Callable[[str, dict], PupilAnalyzer]   # (eye, options) -> analyzer
    status: Callable[[], dict] = field(default=lambda: {"ready": True})
    description: str = ""
    source: str = "builtin"


_REGISTRY: dict[str, AnalyzerEntry] = {}
_PLUGIN_ERRORS: dict[str, str] = {}


def register(name: str, factory, status=None, description: str = "", source: str = "builtin"):
    name = name.strip().lower()
    _REGISTRY[name] = AnalyzerEntry(name, factory, status or (lambda: {"ready": True}), description, source)


def registry() -> dict[str, AnalyzerEntry]:
    return dict(_REGISTRY)


def create(name: str, eye: str, options: dict | None = None) -> PupilAnalyzer:
    entry = _REGISTRY.get(name)
    if entry is None:
        raise AnalyzerError(f"unknown analyzer {name!r}", available=sorted(_REGISTRY))
    return entry.factory(eye, options or {})


def status_all() -> dict:
    out = {}
    for name, entry in sorted(_REGISTRY.items()):
        try:
            status = dict(entry.status())
        except Exception as exc:
            status = {"ready": False, "error": f"{type(exc).__name__}: {exc}"}
        status.update({"description": entry.description, "source": entry.source})
        out[name] = status
    if _PLUGIN_ERRORS:
        out["_plugin_errors"] = dict(_PLUGIN_ERRORS)
    return out


def load_all(settings: dict | None = None):
    """(Re)build the registry: built-ins, plugins, configured commands."""
    _REGISTRY.clear()
    _PLUGIN_ERRORS.clear()
    from . import purest, resnet18, command
    purest.register_builtin(register, settings or {})
    resnet18.register_builtin(register, settings or {})
    plugin_dir = Path(__file__).parent / "plugins"
    for path in sorted(plugin_dir.glob("*.py")):
        if path.name.startswith("_"):
            continue
        module_name = f"plr_analyzer_plugin_{path.stem}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            if hasattr(module, "register_analyzers"):
                module.register_analyzers(register)
        except Exception:
            _PLUGIN_ERRORS[path.name] = traceback.format_exc(limit=3)
    command.register_commands(register, (settings or {}).get("analysis", {}).get("commands") or {})
