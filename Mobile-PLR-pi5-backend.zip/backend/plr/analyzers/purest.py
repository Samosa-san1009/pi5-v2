"""PuReST / PuRe analyzers backed by the native runner in backend/native/purest.

Build once on the Pi (scripts/install_pi5.sh does this):
    cmake -S backend/native/purest -B backend/native/purest/build -DCMAKE_BUILD_TYPE=Release
    cmake --build backend/native/purest/build -j4
Override the binary with PLR_PUREST_BIN.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path

import pandas as pd

from .base import AnalyzerError, PupilAnalyzer, read_trace_csv, validate_trace

BACKEND_DIR = Path(__file__).resolve().parents[2]
DEFAULT_BINARY = BACKEND_DIR / "native" / "purest" / "build" / "plr_purest"


def binary_path() -> Path:
    return Path(os.environ.get("PLR_PUREST_BIN", DEFAULT_BINARY)).expanduser()


def video_frame_count(path: str) -> int | None:
    import cv2

    cap = cv2.VideoCapture(str(path))
    try:
        count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    finally:
        cap.release()
    return count if count > 0 else None


class NativePurestAnalyzer(PupilAnalyzer):
    algorithm = "purest"

    def __init__(self, eye: str, options: dict | None = None):
        super().__init__(eye, options)
        self.name = self.algorithm
        self.binary = binary_path()
        if not self.binary.is_file():
            raise AnalyzerError(
                f"PuReST runner not built: {self.binary}",
                hint="run scripts/build_native.sh (needs cmake, g++, libopencv-dev)",
            )
        self.threshold = float(self.options.get("confidence_threshold", 0.70))

    def analyze(self, video_path: str, progress=None) -> pd.DataFrame:
        frame_count = video_frame_count(video_path)
        with tempfile.TemporaryDirectory(prefix=f"plr_{self.algorithm}_") as work:
            out_csv = Path(work) / "trace.csv"
            cmd = [str(self.binary), "--input", str(video_path), "--output", str(out_csv),
                   "--algorithm", self.algorithm, "--progress", "100"]
            for key, flag in (("min_pupil_mm", "--min-pupil-mm"), ("max_pupil_mm", "--max-pupil-mm")):
                if self.options.get(key):
                    cmd += [flag, str(self.options[key])]
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
            tail = []
            for line in proc.stderr:
                line = line.strip()
                if line.startswith("progress ") and progress and frame_count:
                    progress(min(1.0, int(line.split()[1]) / frame_count))
                else:
                    tail.append(line)
            code = proc.wait()
            if code != 0 or not out_csv.is_file():
                raise AnalyzerError(f"plr_purest exited with {code}", stderr="\n".join(tail[-10:]), video=str(video_path))
            trace = read_trace_csv(str(out_csv), self.threshold)
        return validate_trace(trace, frame_count)

    def metadata(self) -> dict:
        return {"analyzer": self.name, "eye": self.eye, "binary": str(self.binary),
                "confidence_threshold": self.threshold}


class NativePureAnalyzer(NativePurestAnalyzer):
    algorithm = "pure"


_LEGACY_LOCK = threading.Lock()


class LegacyPupilDetectionAnalyzer(PupilAnalyzer):
    """The previous fork's external binary with fixed input/output paths."""

    name = "purest_legacy"

    def __init__(self, eye: str, options: dict | None = None):
        super().__init__(eye, options)
        home = Path.home() / "pupil_detection_new"
        self.binary = Path(os.environ.get("PLR_PUPIL_BIN", home / "build" / "PupilDetection"))
        self.input_video = Path(os.environ.get("PLR_PUPIL_INPUT", home / "videos" / "input" / "output_left_eye.mp4"))
        self.output_csv = Path(os.environ.get("PLR_PUPIL_OUTPUT", home / "videos" / "output" / "output_left_eye.csv"))
        self.threshold = float(self.options.get("confidence_threshold", 0.70))
        if not self.binary.is_file():
            raise AnalyzerError(f"legacy PupilDetection binary not found: {self.binary}")

    def analyze(self, video_path: str, progress=None) -> pd.DataFrame:
        frame_count = video_frame_count(video_path)
        self.input_video.parent.mkdir(parents=True, exist_ok=True)
        self.output_csv.parent.mkdir(parents=True, exist_ok=True)
        with _LEGACY_LOCK:
            self.output_csv.unlink(missing_ok=True)
            shutil.copy2(video_path, self.input_video)
            try:
                result = subprocess.run([str(self.binary)], capture_output=True, text=True)
                if result.returncode != 0 or not self.output_csv.is_file():
                    raise AnalyzerError(f"PupilDetection exited {result.returncode}", stderr=result.stderr[-800:])
                trace = read_trace_csv(str(self.output_csv), self.threshold)
            finally:
                self.input_video.unlink(missing_ok=True)
                self.output_csv.unlink(missing_ok=True)
        return validate_trace(trace, frame_count)


def _native_status() -> dict:
    path = binary_path()
    return {"ready": path.is_file(), "binary": str(path),
            **({} if path.is_file() else {"error": "not built: run scripts/build_native.sh"})}


def _legacy_status() -> dict:
    path = Path(os.environ.get("PLR_PUPIL_BIN", Path.home() / "pupil_detection_new" / "build" / "PupilDetection"))
    return {"ready": path.is_file(), "binary": str(path)}


def register_builtin(register, settings: dict):
    register("purest", NativePurestAnalyzer, _native_status,
             "PuReST pupil tracking (Santini et al. 2018), native C++")
    register("pure", NativePureAnalyzer, _native_status,
             "PuRe per-frame pupil detection (no tracking), native C++")
    register("purest_legacy", LegacyPupilDetectionAnalyzer, _legacy_status,
             "Previous fork's external PupilDetection binary (fixed paths)")
