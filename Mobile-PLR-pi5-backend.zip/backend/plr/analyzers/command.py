"""Run any external program as a pupil analyzer.

Configure in the device settings (POST /settings):

    {"analysis": {"commands": {
        "my_model": {
            "cmd": ["/home/pi/venvs/torch/bin/python", "/home/pi/my_model.py",
                    "--video", "{input}", "--csv", "{output}", "--eye", "{eye}"],
            "description": "my new pupil model",
            "timeout_s": 900
        }
    }}}

The program must write a CSV with columns frame,diameter_px,confidence,valid
(PuReST-style Frame,Valid,Confidence,Diameter_px is also accepted). The model
can use any language or Python environment, since it runs as its own process.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from .base import AnalyzerError, PupilAnalyzer, read_trace_csv, validate_trace
from .purest import video_frame_count


def _make_class(name: str, spec: dict):
    class CommandAnalyzer(PupilAnalyzer):
        def __init__(self, eye: str, options: dict | None = None):
            super().__init__(eye, options)
            self.name = name
            self.cmd = list(spec["cmd"])
            self.timeout = float(spec.get("timeout_s", 1800))
            self.threshold = float(spec.get("confidence_threshold", 0.0))

        def analyze(self, video_path: str, progress=None):
            with tempfile.TemporaryDirectory(prefix=f"plr_{name}_") as work:
                out_csv = str(Path(work) / "trace.csv")
                values = {"input": str(video_path), "output": out_csv, "eye": self.eye}
                cmd = [part.format(**values) for part in self.cmd]
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout)
                except subprocess.TimeoutExpired as exc:
                    raise AnalyzerError(f"{name} timed out after {self.timeout}s") from exc
                if result.returncode != 0 or not Path(out_csv).is_file():
                    raise AnalyzerError(f"{name} exited {result.returncode}", stderr=result.stderr[-800:])
                trace = read_trace_csv(out_csv, self.threshold)
            return validate_trace(trace, video_frame_count(video_path))

        def metadata(self):
            return {"analyzer": name, "eye": self.eye, "cmd": self.cmd}

    return CommandAnalyzer


def register_commands(register, commands: dict):
    for name, spec in (commands or {}).items():
        if not spec or not spec.get("cmd"):
            continue
        program = spec["cmd"][0]

        def status(program=program):
            found = shutil.which(program) or Path(program).is_file()
            return {"ready": bool(found), "program": program}

        register(name, _make_class(name, spec), status, spec.get("description", "external command"), "settings")
