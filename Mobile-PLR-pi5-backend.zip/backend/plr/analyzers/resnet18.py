"""ResNet-18 pupil-diameter models (TFLite preferred on the Pi, ONNX fallback).

Uses the inference modules and weights already in ml_model/inference:
  inference_tflite.py / inference_onnx.py
  model_weights/{left,right}_eye.{tflite,onnx}

Environment overrides (same as the previous fork):
  PLR_RESNET_MODEL_DIR, PLR_RESNET_BACKEND=auto|tflite|onnx,
  PLR_RESNET_LEFT_MODEL, PLR_RESNET_RIGHT_MODEL (and *_TFLITE / *_ONNX)
"""

from __future__ import annotations

import importlib.util
import os
from pathlib import Path

import numpy as np
import pandas as pd

from .base import AnalyzerError, PupilAnalyzer, validate_trace

REPO_ROOT = Path(__file__).resolve().parents[3]
BACKENDS = ("tflite", "onnx")


def model_dir() -> Path:
    return Path(os.environ.get("PLR_RESNET_MODEL_DIR", REPO_ROOT / "ml_model")).expanduser()


def _model_path(root: Path, eye: str, backend: str) -> Path:
    override = os.environ.get(f"PLR_RESNET_{eye.upper()}_{backend.upper()}")
    if override:
        return Path(override).expanduser()
    generic = os.environ.get(f"PLR_RESNET_{eye.upper()}_MODEL")
    if generic and Path(generic).suffix.lower() == f".{backend}":
        return Path(generic).expanduser()
    return root / "inference" / "model_weights" / f"{eye}_eye.{backend}"


def _module_path(root: Path, backend: str) -> Path:
    return root / "inference" / f"inference_{backend}.py"


def _runtime_error(backend: str) -> str | None:
    try:
        import cv2  # noqa: F401  (used by the ml_model inference modules)
        import tqdm  # noqa: F401
        if backend == "onnx":
            import onnxruntime  # noqa: F401
        else:
            try:
                import tflite_runtime.interpreter  # noqa: F401
            except Exception:
                import tensorflow as tf  # noqa: F401
        return None
    except Exception as exc:
        return f"{type(exc).__name__}: {exc}"


def _backend_status(root: Path, backend: str) -> dict:
    errors = []
    module = _module_path(root, backend)
    if not module.is_file():
        errors.append(f"missing inference module {module}")
    runtime = _runtime_error(backend)
    if runtime:
        errors.append(runtime)
    for eye in ("left", "right"):
        path = _model_path(root, eye, backend)
        if not path.is_file():
            errors.append(f"missing {eye} model {path}")
    return {"ready": not errors, "errors": errors}


def select_backend() -> tuple[str, dict]:
    root = model_dir()
    requested = os.environ.get("PLR_RESNET_BACKEND", "auto").strip().lower()
    statuses = {b: _backend_status(root, b) for b in BACKENDS}
    if requested in BACKENDS:
        return requested, statuses
    for backend in BACKENDS:
        if statuses[backend]["ready"]:
            return backend, statuses
    return "tflite", statuses


def status() -> dict:
    backend, statuses = select_backend()
    return {"ready": statuses[backend]["ready"], "selected_backend": backend,
            "model_dir": str(model_dir()), "backends": statuses}


class ResNet18Analyzer(PupilAnalyzer):
    name = "resnet18"

    def __init__(self, eye: str, options: dict | None = None):
        super().__init__(eye, options)
        self.preprocess = str(self.options.get("preprocess", "imagenet"))
        if self.preprocess not in {"imagenet", "clahe"}:
            raise AnalyzerError(f"unsupported ResNet preprocessing {self.preprocess!r}")
        self.backend, statuses = select_backend()
        if not statuses[self.backend]["ready"]:
            raise AnalyzerError("ResNet-18 prerequisites missing", backend=self.backend,
                                errors=statuses[self.backend]["errors"])
        root = model_dir()
        self.model_path = _model_path(root, eye, self.backend)
        spec = importlib.util.spec_from_file_location(f"plr_inference_{self.backend}", _module_path(root, self.backend))
        self.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)
        if self.backend == "tflite":
            self.session = self.module.create_interpreter(str(self.model_path))
        else:
            self.session = self.module.create_session(str(self.model_path))

    def analyze(self, video_path: str, progress=None) -> pd.DataFrame:
        try:
            predictions = self.module.run_inference_on_clip(str(video_path), self.session, preprocess_mode=self.preprocess)
        except Exception as exc:
            raise AnalyzerError("ResNet-18 inference failed", eye=self.eye, backend=self.backend,
                                cause=f"{type(exc).__name__}: {exc}") from exc
        diameter = pd.to_numeric(predictions["pred_diameter_px"], errors="coerce")
        return validate_trace(pd.DataFrame({
            "frame": predictions["frame"].astype(int),
            "diameter_px": diameter,
            "confidence": np.where(np.isfinite(diameter), 1.0, 0.0),
            "valid": np.isfinite(diameter),
        }))

    def metadata(self) -> dict:
        return {"analyzer": self.name, "eye": self.eye, "backend": self.backend,
                "preprocessing": self.preprocess, "model_path": str(self.model_path)}


def register_builtin(register, settings: dict):
    register("resnet18", ResNet18Analyzer, status, "ResNet-18 pupil-diameter regression (ml_model/)")
