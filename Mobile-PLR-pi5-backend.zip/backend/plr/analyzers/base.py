"""Contract every pupil analyzer implements.

An analyzer turns one fixed-scale eye video (one crop per source frame, frame
numbers starting at 0) into a per-frame trace with columns:

    frame        int    source frame index
    diameter_px  float  pupil diameter in pixels (NaN when not found)
    confidence   float  0-1 (use 1.0 if the model has no confidence)
    valid        bool   whether the sample should be used

Everything else (cropping, flash alignment, MCA/MCV, JSON output, the app) is
shared, so a new model only needs this one method.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ("frame", "diameter_px", "confidence", "valid")


class AnalyzerError(RuntimeError):
    def __init__(self, message: str, **details):
        super().__init__(message)
        self.details = details


class PupilAnalyzer(ABC):
    name = "unknown"

    def __init__(self, eye: str, options: dict | None = None):
        self.eye = eye                 # "left" or "right"
        self.options = options or {}

    @abstractmethod
    def analyze(self, video_path: str, progress=None) -> pd.DataFrame:
        """Return a DataFrame with REQUIRED_COLUMNS."""

    def metadata(self) -> dict:
        return {"analyzer": self.name, "eye": self.eye}


def validate_trace(trace: pd.DataFrame, frame_count: int | None = None) -> pd.DataFrame:
    missing = set(REQUIRED_COLUMNS).difference(trace.columns)
    if missing:
        raise ValueError(f"analyzer output is missing columns: {sorted(missing)}")
    if trace.empty:
        raise ValueError("analyzer produced an empty pupil trace")
    clean = trace.loc[:, list(REQUIRED_COLUMNS)].copy()
    clean["frame"] = pd.to_numeric(clean["frame"], errors="raise").astype(int)
    clean["diameter_px"] = pd.to_numeric(clean["diameter_px"], errors="coerce")
    clean["confidence"] = pd.to_numeric(clean["confidence"], errors="coerce").fillna(0.0)
    clean["valid"] = clean["valid"].astype(bool) & np.isfinite(clean["diameter_px"])
    clean = clean.sort_values("frame").drop_duplicates("frame", keep="last")
    if frame_count:
        full = pd.DataFrame({"frame": np.arange(frame_count, dtype=int)})
        clean = full.merge(clean, on="frame", how="left")
        clean["confidence"] = clean["confidence"].fillna(0.0)
        clean["valid"] = clean["valid"].fillna(False).astype(bool)
    return clean.reset_index(drop=True)


def read_trace_csv(path: str, confidence_threshold: float = 0.0) -> pd.DataFrame:
    """Read either the generic CSV contract or PuReST-style capitalised columns."""
    raw = pd.read_csv(path)
    columns = {c.lower(): c for c in raw.columns}
    def col(*names):
        for name in names:
            if name in columns:
                return raw[columns[name]]
        raise ValueError(f"{path} has none of the columns {names}")
    frame = col("frame")
    diameter = pd.to_numeric(col("diameter_px", "diameter"), errors="coerce")
    confidence = pd.to_numeric(col("confidence"), errors="coerce") if "confidence" in columns else pd.Series(1.0, index=raw.index)
    valid_raw = col("valid") if "valid" in columns else np.isfinite(diameter)
    valid = (pd.to_numeric(valid_raw, errors="coerce").fillna(0) != 0) & (confidence.fillna(0) >= confidence_threshold) & np.isfinite(diameter)
    return pd.DataFrame({
        "frame": frame,
        "diameter_px": diameter.where(valid, np.nan),
        "confidence": confidence.fillna(0.0),
        "valid": valid,
    })
