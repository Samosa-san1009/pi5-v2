"""Mobile PLR orchestrator for Raspberry Pi 5."""

__version__ = "2.0.0"
