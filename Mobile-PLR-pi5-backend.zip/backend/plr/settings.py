"""Persistent device settings.

Settings describe the *rig* (pins, LED power, camera, display, default
analyzer). They live in one JSON file so they survive reboots and `git pull`,
and can be changed at runtime with `POST /settings` without touching the app.

Per-session stimulus choices (colour, duration, intensity) still come from the
app's `/session` request, exactly as before.

Path: $PLR_SETTINGS_PATH, default <repo>/device_settings.json (git-ignored).
"""

from __future__ import annotations

import copy
import json
import os
import threading
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]

DEFAULTS: dict = {
    "leds": {
        # Each eye has its own WS2812 on its own GPIO (BCM numbering).
        # power_pct scales everything sent to that LED. Use it to balance the
        # two eyes so that the same requested intensity gives the same light.
        "left": {
            "gpio": 18,
            "power_pct": 100.0,
            "enabled": True,
            "pixel_count": 1,
            "color_order": "GRB",
            "channel_gain": {"r": 1.0, "g": 1.0, "b": 1.0},
        },
        "right": {
            "gpio": 13,
            "power_pct": 100.0,
            "enabled": True,
            "pixel_count": 1,
            "color_order": "GRB",
            "channel_gain": {"r": 1.0, "g": 1.0, "b": 1.0},
        },
        # "auto" = Pi 5 PIO driver if available; "mock" for bench work.
        "backend": "auto",
    },
    "endstops": {
        # Modified optical endstops (IR emitter removed) facing each WS2812.
        "left": {"gpio": 17, "enabled": True, "active": "auto"},
        "right": {"gpio": 27, "enabled": True, "active": "auto"},
        # The modules already have pull-up resistors, so no internal bias.
        "bias": "none",
        # WS2812 PWM below full brightness turns one flash into a burst of
        # short pulses. Pulses closer than this are merged into one flash.
        "merge_gap_us": 3000,
        # Accept an optical onset this long after the LED command at most.
        "max_latency_ms": 30.0,
        # Fail the session if a flash is not seen optically (else fall back
        # to the command time and flag the event).
        "require_optical": False,
    },
    "camera": {
        "index": "auto",
        "resolution": [640, 480],
        "fps": 30,
        "lores": [320, 240],
        "bitrate": 2_000_000,
        # Extra libcamera controls, e.g. {"AeEnable": false,
        # "ExposureTime": 10000, "AnalogueGain": 4.0} for fixed IR exposure.
        "controls": {},
        "hflip": False,
        "vflip": False,
        "hdmi_preview": False,
        # Restart the camera if no frame arrives for this long (idle only).
        "watchdog_s": 5.0,
    },
    "display": {
        "enabled": True,
        "driver": "st7789",
        "spi_port": 0,
        "spi_device": 0,
        "gpio_dc": 24,
        "gpio_rst": 25,
        "width": 240,
        "height": 320,
        # luma rotation 0-3; 1 = landscape so the 320x240 stream fills it.
        "rotate": 1,
        "bus_speed_hz": 40_000_000,
        "fps": 15,
        "overlay": True,
    },
    "analysis": {
        # Used when the app does not ask for an analyzer.
        "default_analyzer": "purest",
        # If set, overrides whatever the app asks for. Lets you swap models
        # while still using the old app, e.g. "resnet18" or a plugin name.
        "force_analyzer": None,
        # Keep analysis off the cores the camera pipeline uses most.
        "cpus": [2, 3],
        "nice": 10,
        "confidence_threshold": 0.70,
        # PuRe/PuReST pupil size assumptions (mm). Tighten max_pupil_mm if the
        # detector ever locks onto the iris instead of the pupil.
        "purest": {"min_pupil_mm": None, "max_pupil_mm": None},
        # Generic external models: {"name": {"cmd": [...], "description": ""}}
        # cmd may use {input} and {output}; output must be a CSV with
        # frame,diameter_px,confidence,valid columns.
        "commands": {},
    },
    "eye_crop": {
        "mode": "detect",
        "left_roi": [0.0, 0.0, 0.5, 1.0],
        "right_roi": [0.5, 0.0, 0.5, 1.0],
        "output_size": 224,
    },
    "session": {
        "pre_roll_s": 1.0,
        "post_roll_s": 3.0,
        "min_gap_s": 3.0,
        "window_pre_s": 1.5,
        "window_post_s": 3.0,
        "keep_eye_crops": False,
    },
    "server": {"port": 5000},
}


def _deep_merge(base: dict, update: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in (update or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict) and key not in ("controls", "commands"):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _clamp(value, low, high, name):
    value = float(value)
    if not low <= value <= high:
        raise ValueError(f"{name} must be between {low} and {high}, got {value}")
    return value


def validate(settings: dict) -> dict:
    """Raise ValueError on settings that would misbehave on hardware."""
    used: dict[int, str] = {}

    def claim(gpio, owner):
        gpio = int(gpio)
        if not 0 <= gpio <= 27:
            raise ValueError(f"{owner}: GPIO{gpio} is not a header GPIO")
        if gpio in used:
            raise ValueError(f"GPIO{gpio} is used by both {used[gpio]} and {owner}")
        used[gpio] = owner

    for side in ("left", "right"):
        led = settings["leds"][side]
        claim(led["gpio"], f"leds.{side}")
        _clamp(led["power_pct"], 0, 100, f"leds.{side}.power_pct")
        if int(led["pixel_count"]) < 1:
            raise ValueError(f"leds.{side}.pixel_count must be >= 1")
        if sorted(str(led["color_order"]).upper()) != ["B", "G", "R"]:
            raise ValueError(f"leds.{side}.color_order must be a permutation of RGB")
        for channel, gain in led.get("channel_gain", {}).items():
            _clamp(gain, 0, 1, f"leds.{side}.channel_gain.{channel}")
        stop = settings["endstops"][side]
        if stop.get("enabled", True):
            claim(stop["gpio"], f"endstops.{side}")
        if str(stop.get("active", "auto")).lower() not in {"auto", "low", "high"}:
            raise ValueError(f"endstops.{side}.active must be auto, low or high")

    display = settings["display"]
    if display.get("enabled"):
        for key in ("gpio_dc", "gpio_rst"):
            claim(display[key], f"display.{key}")
        # SPI0 pins (CE0, MOSI, SCLK) belong to the display.
        for gpio, name in ((8, "SPI0 CE0"), (10, "SPI0 MOSI"), (11, "SPI0 SCLK")):
            if gpio in used:
                raise ValueError(f"GPIO{gpio} ({name}) is needed by the display but assigned to {used[gpio]}")
            used[gpio] = f"display {name}"
    for gpio, name in ((2, "I2C SDA (RTC)"), (3, "I2C SCL (RTC)")):
        if gpio in used:
            raise ValueError(f"GPIO{gpio} is reserved for {name} but assigned to {used[gpio]}")

    if str(settings["endstops"]["bias"]).lower() not in {"none", "pull_up", "pull_down"}:
        raise ValueError("endstops.bias must be none, pull_up or pull_down")
    width, height = settings["camera"]["resolution"]
    if int(width) % 2 or int(height) % 2:
        raise ValueError("camera.resolution must be even")
    _clamp(settings["camera"]["fps"], 1, 120, "camera.fps")
    return settings


class SettingsStore:
    def __init__(self, path: str | os.PathLike | None = None):
        self.path = Path(path or os.environ.get("PLR_SETTINGS_PATH", REPO_ROOT / "device_settings.json"))
        self._lock = threading.RLock()
        self._data = self._load()

    def _load(self) -> dict:
        data = copy.deepcopy(DEFAULTS)
        if self.path.is_file():
            try:
                data = _deep_merge(data, json.loads(self.path.read_text(encoding="utf-8")))
            except Exception as exc:  # a broken file must not stop the rig booting
                print(f"  [settings] ignoring unreadable {self.path}: {exc}")
        return validate(data)

    def get(self) -> dict:
        with self._lock:
            return copy.deepcopy(self._data)

    def section(self, name: str) -> dict:
        with self._lock:
            return copy.deepcopy(self._data[name])

    def update(self, patch: dict) -> dict:
        with self._lock:
            candidate = validate(_deep_merge(self._data, patch or {}))
            self._write(candidate)
            self._data = candidate
            return copy.deepcopy(candidate)

    def reset(self) -> dict:
        with self._lock:
            self._data = validate(copy.deepcopy(DEFAULTS))
            self._write(self._data)
            return copy.deepcopy(self._data)

    def _write(self, data: dict):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)
