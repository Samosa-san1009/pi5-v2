"""Live IR preview on the GMT020-02 ST7789 TFT (SPI0, DC=GPIO24, RST=GPIO25).

Replaces ir_display.py / ir-display.service from the led-test repo. That
service opened the camera itself, which would block the PLR server from
recording. Here the display only reads the lores frames the camera service
already publishes, so it cannot interfere with the recorded stream.

Overlay (optional): stage, REC indicator, which LED is lit, clock + its source
(NTP/RTC), the Pi's IP address (handy for typing into the app), and a centre
line to help line up both eyes.
"""

from __future__ import annotations

import os
import socket
import threading
import time
from datetime import datetime

from . import timebase


def _local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("10.255.255.255", 1))
            return sock.getsockname()[0]
    except Exception:
        return "no network"


class TftDisplay:
    def __init__(self, settings: dict, camera, state_provider, leds=None):
        self.settings = settings
        self.camera = camera
        self.state_provider = state_provider  # callable -> dict(stage=..., ...)
        self.error: str | None = None
        self.frames_shown = 0
        self._device = None
        self._stop = threading.Event()
        self._thread = None
        self._led_rgb = {"left": (0, 0, 0), "right": (0, 0, 0)}
        self._ip = _local_ip()
        self._ip_checked = time.monotonic()
        self._clock_source = "?"
        self._clock_checked = 0.0
        if leds is not None:
            leds.state_listeners.append(self._on_led)

    def _on_led(self, side, rgb, _t):
        self._led_rgb[side] = rgb

    def start(self):
        if not self.settings.get("enabled", True):
            self.error = "disabled in settings"
            return
        if os.environ.get("PLR_HARDWARE", "").lower() == "mock":
            self.error = "mock hardware: display not driven"
            return
        self._thread = threading.Thread(target=self._run, name="tft-display", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def status(self) -> dict:
        return {
            "enabled": bool(self.settings.get("enabled", True)),
            "running": self._device is not None,
            "frames_shown": self.frames_shown,
            "error": self.error,
        }

    def _make_device(self):
        from luma.core.interface.serial import spi
        from luma.lcd.device import st7789

        cfg = self.settings
        serial = spi(
            port=int(cfg["spi_port"]),
            device=int(cfg["spi_device"]),
            gpio_DC=int(cfg["gpio_dc"]),
            gpio_RST=int(cfg["gpio_rst"]),
            bus_speed_hz=int(cfg["bus_speed_hz"]),
        )
        return st7789(serial, width=int(cfg["width"]), height=int(cfg["height"]),
                      rotate=int(cfg["rotate"]), active_low=False)

    def _run(self):
        from PIL import Image

        period = 1.0 / max(1.0, float(self.settings.get("fps", 15)))
        seq = 0
        backoff = 2.0
        while not self._stop.is_set():
            if self._device is None:
                try:
                    self._device = self._make_device()
                    self.error = None
                    backoff = 2.0
                except Exception as exc:
                    self.error = f"{type(exc).__name__}: {exc}"
                    self._stop.wait(backoff)
                    backoff = min(30.0, backoff * 2)
                    continue
            item = self.camera.sink.wait(seq, timeout=1.0)
            if item is None:
                self._show_message("waiting for camera")
                continue
            seq, grey, _ts = item
            started = time.monotonic()
            try:
                img = Image.fromarray(grey, "L").convert("RGB")
                size = (self._device.width, self._device.height)
                if img.size != size:
                    img = img.resize(size)
                if self.settings.get("overlay", True):
                    self._draw_overlay(img)
                self._device.display(img)
                self.frames_shown += 1
            except Exception as exc:
                self.error = f"{type(exc).__name__}: {exc}"
                self._device = None
                continue
            self._stop.wait(max(0.0, period - (time.monotonic() - started)))

    def _show_message(self, text: str):
        if self._device is None:
            return
        try:
            from PIL import Image, ImageDraw

            img = Image.new("RGB", (self._device.width, self._device.height), "black")
            ImageDraw.Draw(img).text((8, 8), text, fill="white")
            self._device.display(img)
        except Exception:
            self._device = None

    def _draw_overlay(self, img):
        from PIL import ImageDraw

        now = time.monotonic()
        if now - self._ip_checked > 30:
            self._ip, self._ip_checked = _local_ip(), now
        if now - self._clock_checked > 30:
            try:
                self._clock_source = timebase.clock_status()["wall_clock_source"]
            except Exception:
                self._clock_source = "?"
            self._clock_checked = now

        draw = ImageDraw.Draw(img)
        width, height = img.size
        state = self.state_provider() or {}
        stage = str(state.get("stage", "idle")).upper()
        draw.rectangle((0, 0, width, 14), fill=(0, 0, 0))
        draw.text((3, 2), stage, fill=(255, 255, 255))
        if self.camera.recording:
            draw.ellipse((width - 44, 3, width - 36, 11), fill=(255, 0, 0))
            draw.text((width - 32, 2), "REC", fill=(255, 0, 0))
        clock = datetime.now().strftime("%H:%M:%S")
        draw.text((width // 2 - 40, 2), f"{clock} {self._clock_source[:4]}", fill=(180, 180, 180))
        draw.line((width // 2, 16, width // 2, height - 16), fill=(60, 60, 60))
        for side, x in (("left", 6), ("right", width - 14)):
            rgb = self._led_rgb.get(side, (0, 0, 0))
            if max(rgb) > 0:
                draw.rectangle((x, 20, x + 8, 28), fill=tuple(min(255, c * 4) for c in rgb), outline=(255, 255, 255))
        draw.rectangle((0, height - 13, width, height), fill=(0, 0, 0))
        draw.text((3, height - 12), f"{self._ip}:{state.get('port', 5000)}", fill=(120, 220, 255))
