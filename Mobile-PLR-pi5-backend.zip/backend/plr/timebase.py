"""Clocks, the RTC, and how every timestamp in a session relates to the others.

Measurement timing never uses wall-clock time. Camera frames (libcamera
SensorTimestamp) and endstop edges (kernel GPIO events) are both stamped by
the kernel on CLOCK_MONOTONIC, so they can be compared directly with
sub-millisecond precision.

Wall-clock time is only used to name and date sessions. It comes from NTP when
the Pi has network, otherwise from the RTC. The Pi 5 has its own RTC
(rpi-rtc, needs a battery on J5); an external DS1307/DS3231 on I2C shows up as
a second /dev/rtcN. If the system clock looks wrong at boot (no network, no
battery), sessions are dated from the external RTC instead.
"""

from __future__ import annotations

import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

# Anything earlier than this means the clock was never set.
_PLAUSIBLE_EPOCH_S = datetime(2025, 1, 1, tzinfo=timezone.utc).timestamp()
_CLOCKS = {
    "monotonic": time.CLOCK_MONOTONIC,
    "boottime": getattr(time, "CLOCK_BOOTTIME", time.CLOCK_MONOTONIC),
    "realtime": time.CLOCK_REALTIME,
}
_ntp_cache: tuple[float, bool | None] = (0.0, None)


def now_ns(clock: str = "monotonic") -> int:
    return time.clock_gettime_ns(_CLOCKS[clock])


def anchor() -> dict:
    """Sample all clocks as close together as possible.

    The pair (monotonic_ns, realtime_ns) lets any kernel timestamp from this
    boot be converted to wall-clock time later.
    """
    best = None
    for _ in range(7):
        a = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        rt = time.clock_gettime_ns(time.CLOCK_REALTIME)
        bt = time.clock_gettime_ns(_CLOCKS["boottime"])
        b = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
        if best is None or (b - a) < best[0]:
            best = (b - a, (a + b) // 2, rt, bt)
    span, mono, real, boot = best
    return {
        "monotonic_ns": mono,
        "realtime_ns": real,
        "boottime_ns": boot,
        "sample_span_ns": span,
        "realtime_iso": datetime.fromtimestamp(real / 1e9, tz=timezone.utc).isoformat(),
    }


def detect_clock(timestamp_ns: int) -> str:
    """Return which kernel clock a timestamp most likely came from."""
    readings = {name: time.clock_gettime_ns(cid) for name, cid in _CLOCKS.items()}
    return min(readings, key=lambda name: abs(readings[name] - int(timestamp_ns)))


def to_monotonic_ns(timestamp_ns: int, clock: str) -> int:
    """Convert a timestamp from `clock` into CLOCK_MONOTONIC."""
    if clock == "monotonic":
        return int(timestamp_ns)
    a = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    other = time.clock_gettime_ns(_CLOCKS[clock])
    b = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    return int(timestamp_ns) - other + (a + b) // 2


# ── RTC ─────────────────────────────────────────────────────────────────────

def list_rtcs() -> list[dict]:
    rtcs = []
    for node in sorted(Path("/sys/class/rtc").glob("rtc*")):
        info = {"device": f"/dev/{node.name}", "name": _read(node / "name")}
        epoch = _read(node / "since_epoch")
        if epoch and epoch.isdigit():
            info["since_epoch"] = int(epoch)
        info["external"] = bool(info["name"]) and "rpi" not in info["name"].lower()
        hctosys = _read(node / "hctosys")
        info["sets_clock_at_boot"] = hctosys == "1"
        rtcs.append(info)
    return rtcs


def external_rtc() -> dict | None:
    for rtc in list_rtcs():
        if rtc["external"] and "since_epoch" in rtc:
            return rtc
    return None


def ntp_synchronized() -> bool | None:
    global _ntp_cache
    checked_at, value = _ntp_cache
    if time.monotonic() - checked_at < 30:
        return value
    try:
        out = subprocess.run(
            ["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
            capture_output=True, text=True, timeout=2,
        )
        value = out.stdout.strip() == "yes" if out.returncode == 0 else None
    except Exception:
        value = None
    _ntp_cache = (time.monotonic(), value)
    return value


def clock_status() -> dict:
    system_s = time.time()
    rtcs = list_rtcs()
    ext = next((r for r in rtcs if r["external"] and "since_epoch" in r), None)
    ntp = ntp_synchronized()
    status = {
        "system_time": datetime.fromtimestamp(system_s).isoformat(timespec="seconds"),
        "system_time_plausible": system_s >= _PLAUSIBLE_EPOCH_S,
        "ntp_synchronized": ntp,
        "rtcs": rtcs,
        "external_rtc": ext["device"] if ext else None,
    }
    if ext:
        drift = system_s - ext["since_epoch"]
        status["external_rtc_drift_s"] = round(drift, 1)
    if ntp:
        source = "ntp"
    elif ext and abs(status.get("external_rtc_drift_s", 1e9)) < 5:
        source = "rtc"
    elif ext:
        source = "rtc_disagrees_with_system"
    elif status["system_time_plausible"]:
        source = "system_unverified"
    else:
        source = "unset"
    status["wall_clock_source"] = source
    return status


def session_datetime() -> tuple[datetime, str]:
    """Best available local wall-clock time for naming a session."""
    status = clock_status()
    if status["system_time_plausible"] and status["wall_clock_source"] != "rtc_disagrees_with_system":
        return datetime.now(), status["wall_clock_source"]
    ext = external_rtc()
    if ext and ext["since_epoch"] >= _PLAUSIBLE_EPOCH_S:
        return datetime.fromtimestamp(ext["since_epoch"]), "external_rtc"
    return datetime.now(), status["wall_clock_source"]


def _read(path: Path) -> str | None:
    try:
        return path.read_text().strip()
    except Exception:
        return None
