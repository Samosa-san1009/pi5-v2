"""Run a session analysis in its own low-priority process.

The analysis (eye cropping, PuReST or a neural model) is CPU heavy. Running it
in a separate process, at a lower priority and pinned to the CPU cores the
camera pipeline uses least, keeps the always-on camera stream, the TFT and
the HTTP server responsive while it works.
"""

from __future__ import annotations

import logging
import multiprocessing as mp
import os
import queue
import traceback


def _child(job: dict, events: "mp.Queue"):
    try:
        os.nice(int(job.get("nice", 10)))
    except Exception:
        pass
    cpus = job.get("cpus")
    if cpus:
        try:
            available = os.sched_getaffinity(0)
            wanted = {int(c) for c in cpus} & available
            if wanted:
                os.sched_setaffinity(0, wanted)
        except Exception:
            pass

    logger = logging.getLogger(f"plr.analysis.{job['session_id']}")
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler(job["log_path"], encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s [analysis] %(message)s"))
    logger.addHandler(handler)
    try:
        from plr import analyzers
        from plr.analysis.pipeline import AnalysisPipeline

        analyzers.load_all(job["settings"])

        def progress(stage, eye, fraction):
            events.put({"type": "progress", "stage": stage, "eye": eye, "fraction": round(float(fraction), 3)})

        logger.info("analyzer=%s options=%s", job["analyzer"], job.get("analyzer_options"))
        result = AnalysisPipeline(
            session_dir=job["session_dir"],
            analyzer_name=job["analyzer"],
            analyzer_options=job.get("analyzer_options") or {},
            settings=job["settings"],
            session_id=job["session_id"],
            participant=job.get("participant"),
            progress=progress,
            logger=logger,
            output_suffix=job.get("output_suffix", ""),
        ).run()
        logger.info("analysis finished: %s", result["status"])
        events.put({"type": "result", "result": result})
    except Exception as exc:
        logger.exception("analysis crashed")
        events.put({"type": "error", "error": str(exc), "error_type": type(exc).__name__,
                    "traceback": traceback.format_exc(limit=5)})
    finally:
        handler.close()


def run_analysis(job: dict, on_progress=None, timeout_s: float = 3600) -> dict:
    """Run `job` in a child process; block until it finishes; return the result."""
    ctx = mp.get_context("spawn")  # never fork a process that owns the camera
    events = ctx.Queue()
    proc = ctx.Process(target=_child, args=(job, events), name=f"plr-analysis-{job['session_id']}", daemon=True)
    proc.start()
    outcome = None
    waited = 0.0
    while outcome is None:
        try:
            message = events.get(timeout=0.5)
        except queue.Empty:
            waited += 0.5
            if not proc.is_alive():
                break
            if waited > timeout_s:
                proc.terminate()
                raise TimeoutError(f"analysis exceeded {timeout_s}s")
            continue
        if message["type"] == "progress":
            if on_progress:
                on_progress(message)
        else:
            outcome = message
    proc.join(timeout=10)
    if outcome is None:
        raise RuntimeError(f"analysis process exited with code {proc.exitcode} and no result")
    if outcome["type"] == "error":
        error = RuntimeError(outcome["error"])
        error.details = {"error_type": outcome["error_type"], "traceback": outcome["traceback"]}
        raise error
    return outcome["result"]
