"""Full-video pupilogram + flash-aligned PLR metrics for one session.

Same output files and JSON shape the app already reads (pupilogram.json,
metrics.json), with two improvements over the previous fork:

  * Each sample's time_s comes from the camera's per-frame sensor timestamps
    (frames.csv), not frame_index / nominal fps, so dropped frames or fps
    drift no longer shift the trace.
  * Flash onsets come from the endstops (events.json), measured optically.
"""

from __future__ import annotations

import csv
import json
import os
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from .. import analyzers
from .eye_cropper import EyeCropper
from .plr_metrics import calculate_plr_metrics

EYES = ((1, "left"), (2, "right"))


def load_frame_times(path: Path) -> np.ndarray | None:
    if not path.is_file():
        return None
    with open(path, newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        return None
    return np.array([float(r["time_s"]) for r in rows], dtype=float)


def video_fps(path: str) -> float:
    import cv2

    cap = cv2.VideoCapture(str(path))
    try:
        fps = float(cap.get(cv2.CAP_PROP_FPS))
    finally:
        cap.release()
    return fps if fps > 0 else 30.0


def apply_crop_settings(eye_crop: dict):
    """EyeCropper reads its configuration from environment variables."""
    os.environ["PLR_EYE_CROP_MODE"] = str(eye_crop.get("mode", "detect"))
    os.environ["PLR_LEFT_EYE_ROI"] = ",".join(str(v) for v in eye_crop.get("left_roi", [0, 0, 0.5, 1]))
    os.environ["PLR_RIGHT_EYE_ROI"] = ",".join(str(v) for v in eye_crop.get("right_roi", [0.5, 0, 0.5, 1]))
    os.environ.setdefault("PLR_LEFT_EYE_DETECT_ROI", os.environ["PLR_LEFT_EYE_ROI"])
    os.environ.setdefault("PLR_RIGHT_EYE_DETECT_ROI", os.environ["PLR_RIGHT_EYE_ROI"])
    os.environ["PLR_EYE_CROP_OUTPUT_SIZE"] = str(eye_crop.get("output_size", 224))


class AnalysisPipeline:
    def __init__(self, session_dir: str, analyzer_name: str, analyzer_options: dict, settings: dict,
                 session_id: str, participant: dict | None = None, progress=None, logger=None,
                 output_suffix: str = ""):
        self.session_dir = Path(session_dir)
        self.analyzer_name = analyzer_name
        self.analyzer_options = dict(analyzer_options or {})
        self.analyzer_options.setdefault("confidence_threshold", settings["analysis"].get("confidence_threshold", 0.7))
        if analyzer_name in ("purest", "pure"):
            for key, value in (settings["analysis"].get("purest") or {}).items():
                if value is not None:
                    self.analyzer_options.setdefault(key, value)
        self.settings = settings
        self.session_id = session_id
        self.participant = participant or {}
        self.progress = progress or (lambda **_: None)
        self.log = logger
        self.window_pre_s = float(settings["session"].get("window_pre_s", 1.5))
        self.window_post_s = float(settings["session"].get("window_post_s", 3.0))
        self.keep_crops = bool(settings["session"].get("keep_eye_crops", False))
        self.pupilogram_path = self.session_dir / f"pupilogram{output_suffix}.json"
        self.metrics_path = self.session_dir / f"metrics{output_suffix}.json"

    def _info(self, msg, *args):
        if self.log:
            self.log.info(msg, *args)

    def run(self) -> dict:
        video = self.session_dir / "full_video.mp4"
        timeline = json.loads((self.session_dir / "events.json").read_text(encoding="utf-8"))
        events = sorted(timeline.get("events", []), key=lambda e: e["onset_s"])
        frame_times = load_frame_times(self.session_dir / "frames.csv")
        source_fps = video_fps(str(video))
        apply_crop_settings(self.settings.get("eye_crop", {}))

        traces: dict[int, dict | None] = {}
        failures, failure_details = {}, {}
        crop_root = self.session_dir / "eye_crops" if self.keep_crops else None
        with tempfile.TemporaryDirectory(prefix=f"plr_{self.session_id}_") as tmp:
            workspace = crop_root or Path(tmp)
            workspace.mkdir(parents=True, exist_ok=True)
            cropper = EyeCropper(str(workspace))
            for step, (led_index, eye) in enumerate(EYES):
                base = step / len(EYES)
                try:
                    self.progress(stage="cropping", eye=eye, fraction=base)
                    crop_path, crop_meta = cropper.crop(str(video), led_index)
                    analyzer = analyzers.create(self.analyzer_name, eye, self.analyzer_options)
                    self.progress(stage="analyzing", eye=eye, fraction=base + 0.25 / len(EYES))

                    def report(fraction, _base=base, _eye=eye):
                        self.progress(stage="analyzing", eye=_eye, fraction=_base + (0.25 + 0.75 * fraction) / len(EYES))

                    trace = analyzers.validate_trace(analyzer.analyze(crop_path, progress=report))
                    times, time_base = self._times_for(trace["frame"].to_numpy(), frame_times, source_fps)
                    traces[led_index] = {
                        "data": trace, "times": times, "time_base": time_base, "fps": source_fps,
                        "crop": crop_meta, "analyzer": analyzer.name, "analyzer_config": analyzer.metadata(),
                    }
                    self._info("%s eye: %d samples, %d valid", eye, len(trace), int(trace["valid"].sum()))
                except Exception as exc:
                    if self.log:
                        self.log.exception("analysis failed for %s eye", eye)
                    failures[eye] = str(exc)
                    failure_details[eye] = {"error": str(exc), "error_type": type(exc).__name__,
                                            **(getattr(exc, "details", None) or {})}
                    traces[led_index] = None

        metric_events = [self._event_metrics(e, traces, failure_details) for e in events]
        ok_eyes = sum(t is not None for t in traces.values())
        event_errors = sum(e["status"] != "ok" for e in metric_events)
        status = "error" if ok_eyes == 0 else ("partial" if ok_eyes < 2 or event_errors else "ok")

        pupilogram = {
            "schema_version": 2,
            "session_id": self.session_id,
            "analyzer": self._analyzer_summary(traces),
            "analyzer_config": {eye: (traces[i] or {}).get("analyzer_config") for i, eye in EYES},
            "unit": "px",
            "time_base": next((t["time_base"] for t in traces.values() if t), None),
            "source_video": {"path": str(video), "fps": round(source_fps, 6),
                             "frames_with_timestamps": int(len(frame_times)) if frame_times is not None else 0},
            "eyes": {eye: self._trace_output(traces.get(i)) for i, eye in EYES},
            "failures": failures,
            "failure_details": failure_details,
        }
        metrics = {
            "schema_version": 2,
            "session_id": self.session_id,
            "participant": self.participant,
            "status": status,
            "unit": "px",
            "analyzer": self.analyzer_name,
            "definitions": {
                "mca": "baseline median minus minimum post-flash diameter",
                "mcv": "largest constriction speed from onset to minimum",
                "latency": "constriction onset minus optically measured flash onset",
            },
            "flash_timing": timeline.get("optical"),
            "warnings": timeline.get("warnings", []),
            "events": metric_events,
        }
        self._write(self.pupilogram_path, pupilogram)
        self._write(self.metrics_path, metrics)
        self.progress(stage="done", eye=None, fraction=1.0)
        return {"status": status, "pupilogram": str(self.pupilogram_path), "metrics": str(self.metrics_path)}

    # ── helpers ─────────────────────────────────────────────────────────────
    @staticmethod
    def _times_for(frames: np.ndarray, frame_times: np.ndarray | None, fps: float):
        if frame_times is not None and len(frame_times) and frames.max() < len(frame_times):
            return frame_times[frames], "sensor_timestamps"
        return frames.astype(float) / fps, "nominal_fps"

    def _event_metrics(self, event: dict, traces: dict, failure_details: dict) -> dict:
        direct_index = event["led_index"]
        other_index = 2 if direct_index == 1 else 1
        names = {1: "left", 2: "right"}
        direct = self._window(traces.get(direct_index), event["onset_s"], failure_details.get(names[direct_index]))
        consensual = self._window(traces.get(other_index), event["onset_s"], failure_details.get(names[other_index]))
        statuses = {direct["status"], consensual["status"]}
        status = "error" if statuses == {"error"} else ("partial" if "error" in statuses else "ok")
        return {"event_id": event.get("event_id"), "status": status, "stimulus": event,
                "direct": direct, "consensual": consensual}

    def _window(self, trace: dict | None, onset_s: float, failure: dict | None) -> dict:
        if trace is None:
            out = {"status": "error", "error": "eye trace unavailable"}
            if failure:
                out["details"] = failure
            return out
        data, times = trace["data"], trace["times"]
        mask = ((times >= max(0.0, onset_s - self.window_pre_s)) & (times <= onset_s + self.window_post_s)
                & data["valid"].to_numpy(dtype=bool))
        if not mask.any():
            return {"status": "error", "error": "no valid samples in event window"}
        try:
            result = calculate_plr_metrics(
                data["frame"].to_numpy()[mask], data["diameter_px"].to_numpy()[mask],
                fps=trace["fps"], flash_onset_s=onset_s,
                smoothing_window=int(os.environ.get("PLR_SMOOTHING_WINDOW", "5")),
                times_s=times[mask],
            )
            result.pop("diameter_series", None)
            return {"status": "ok", "time_base": trace["time_base"], **result}
        except Exception as exc:
            return {"status": "error", "error": str(exc)}

    @staticmethod
    def _trace_output(trace: dict | None):
        if trace is None:
            return None
        samples = []
        for (frame, diameter, confidence, valid), t in zip(
                trace["data"][["frame", "diameter_px", "confidence", "valid"]].itertuples(index=False), trace["times"]):
            finite = bool(np.isfinite(diameter))
            samples.append({
                "frame": int(frame),
                "time_s": round(float(t), 6),
                "diameter_px": round(float(diameter), 4) if finite else None,
                "confidence": round(float(confidence), 4) if np.isfinite(confidence) else None,
                "valid": bool(valid and finite),
            })
        return {"fps": round(float(trace["fps"]), 6), "time_base": trace["time_base"], "analyzer": trace["analyzer"],
                "analyzer_config": trace["analyzer_config"], "crop": trace["crop"], "samples": samples}

    @staticmethod
    def _analyzer_summary(traces: dict):
        names = {t["analyzer"] for t in traces.values() if t}
        if len(names) == 1:
            return names.pop()
        return {"left": (traces.get(1) or {}).get("analyzer"), "right": (traces.get(2) or {}).get("analyzer")}

    @staticmethod
    def _write(path: Path, payload: dict):
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
        os.replace(tmp, path)
