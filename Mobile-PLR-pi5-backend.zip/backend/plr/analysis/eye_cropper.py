"""Create frame-aligned, fixed-scale eye videos for pupil analysis.

Detection is intentionally two-pass. The first pass locates the eye through
the full recording and chooses one source-pixel crop size. The second pass
writes exactly one crop for every source frame using that constant size.
Only the center may move, so pupil diameter is never changed by a varying
resize scale and frame numbers stay aligned with the source video.
"""

from __future__ import annotations

import os
from pathlib import Path
from statistics import median


DEFAULT_ROIS = {
    1: (0.0, 0.0, 0.5, 1.0),
    2: (0.5, 0.0, 0.5, 1.0),
}
EYE_LABELS = {1: "left", 2: "right"}


def _parse_roi(value: str | None, default: tuple[float, float, float, float]):
    if not value:
        return default
    try:
        roi = tuple(float(part.strip()) for part in value.split(","))
    except ValueError as exc:
        raise ValueError(f"Invalid ROI {value!r}; expected x,y,width,height") from exc
    if len(roi) != 4:
        raise ValueError(f"Invalid ROI {value!r}; expected four values")
    x, y, width, height = roi
    if min(x, y, width, height) < 0 or width <= 0 or height <= 0:
        raise ValueError(f"Invalid normalized ROI: {roi}")
    if x + width > 1.0 or y + height > 1.0:
        raise ValueError(f"Normalized ROI must stay inside the frame: {roi}")
    return roi


def _env_int(name: str, default: int, minimum: int = 1) -> int:
    value = int(os.environ.get(name, str(default)))
    if value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return value


def _env_float(name: str, default: float, minimum: float = 0.0) -> float:
    value = float(os.environ.get(name, str(default)))
    if value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    return value


def _env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


class EyeCropper:
    def __init__(self, output_dir: str, ffmpeg_bin: str = "ffmpeg"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.rois = {
            1: _parse_roi(os.environ.get("PLR_LEFT_EYE_ROI"), DEFAULT_ROIS[1]),
            2: _parse_roi(os.environ.get("PLR_RIGHT_EYE_ROI"), DEFAULT_ROIS[2]),
        }
        self.detection_search_rois = {
            1: _parse_roi(os.environ.get("PLR_LEFT_EYE_DETECT_ROI"), DEFAULT_ROIS[1]),
            2: _parse_roi(os.environ.get("PLR_RIGHT_EYE_DETECT_ROI"), DEFAULT_ROIS[2]),
        }
        self.mode = os.environ.get("PLR_EYE_CROP_MODE", "detect").strip().lower()
        if self.mode not in {"detect", "static"}:
            raise ValueError("PLR_EYE_CROP_MODE must be 'detect' or 'static'")
        cascade_path = os.environ.get("PLR_EYE_CASCADE")
        self.cascade_path = Path(cascade_path) if cascade_path else None

    def crop(self, video_path: str, led_index: int) -> tuple[str, dict]:
        if led_index not in EYE_LABELS:
            raise ValueError(f"No crop configuration for eye {led_index}")
        if self.mode == "static":
            return self._crop_static(video_path, led_index)
        return self._crop_detected(video_path, led_index)

    def _crop_detected(self, video_path: str, led_index: int) -> tuple[str, dict]:
        cv2 = self._cv2()
        import numpy as np

        source = Path(video_path)
        cap, fps, frame_width, frame_height = self._open_video(cv2, source)
        cascade_path = self.cascade_path or Path(cv2.data.haarcascades) / "haarcascade_eye.xml"
        detector = cv2.CascadeClassifier(str(cascade_path))
        if detector.empty():
            cap.release()
            raise RuntimeError(f"OpenCV could not load eye cascade: {cascade_path}")

        search_roi = self._normalized_to_pixel_roi(
            self.detection_search_rois[led_index],
            frame_width,
            frame_height,
        )
        padding = _env_float("PLR_EYE_BOX_PADDING", 0.45)
        min_eye_size = _env_int("PLR_EYE_MIN_SIZE_PX", 20)
        min_neighbors = _env_int("PLR_EYE_MIN_NEIGHBORS", 5)
        scale_factor = _env_float("PLR_EYE_SCALE_FACTOR", 1.1, 1.01)
        detections_by_frame: list[tuple[int, int, int, int] | None] = []

        while True:
            ok, frame = cap.read()
            if not ok:
                break
            rx, ry, rw, rh = search_roi
            gray = cv2.cvtColor(frame[ry : ry + rh, rx : rx + rw], cv2.COLOR_BGR2GRAY)
            boxes = detector.detectMultiScale(
                gray,
                scaleFactor=scale_factor,
                minNeighbors=min_neighbors,
                minSize=(min_eye_size, min_eye_size),
            )
            boxes = [
                (int(x) + rx, int(y) + ry, int(width), int(height))
                for x, y, width, height in boxes
            ]
            detections_by_frame.append(self._select_best_eye_box(self._dedupe_boxes(boxes)))
        cap.release()

        detected = [(index, box) for index, box in enumerate(detections_by_frame) if box is not None]
        if not detected:
            raise RuntimeError(
                f"No {EYE_LABELS[led_index]} eye detected in {source}. "
                "Use a fixed ROI if the camera mount is calibrated."
            )

        explicit_size = os.environ.get("PLR_EYE_FIXED_BOX_SIZE_PX")
        if explicit_size:
            fixed_size = int(explicit_size)
        else:
            expanded_sizes = [
                self._expanded_size(box, padding) for _, box in detected
            ]
            percentile = _env_float("PLR_EYE_BOX_SIZE_PERCENTILE", 95.0)
            fixed_size = int(round(float(np.percentile(expanded_sizes, min(100.0, percentile)))))
        fixed_size = self._valid_even_size(fixed_size, frame_width, frame_height)

        frame_indices = [index for index, _ in detected]
        centers_x = [box[0] + box[2] / 2.0 for _, box in detected]
        centers_y = [box[1] + box[3] / 2.0 for _, box in detected]
        all_indices = np.arange(len(detections_by_frame), dtype=float)
        tracked_x = np.interp(all_indices, frame_indices, centers_x)
        tracked_y = np.interp(all_indices, frame_indices, centers_y)
        smooth_window = _env_int("PLR_EYE_CENTER_SMOOTHING_FRAMES", 7)
        tracked_x = self._moving_median(tracked_x, smooth_window)
        tracked_y = self._moving_median(tracked_y, smooth_window)
        boxes = [
            self._square_at_center(x, y, fixed_size, frame_width, frame_height)
            for x, y in zip(tracked_x, tracked_y)
        ]

        output, frames_written = self._write_crops(
            cv2,
            source,
            led_index,
            fps,
            frame_width,
            frame_height,
            boxes,
        )
        if frames_written != len(detections_by_frame):
            output.unlink(missing_ok=True)
            raise RuntimeError(
                f"Frame alignment failed: source={len(detections_by_frame)}, "
                f"cropped={frames_written}"
            )

        output_size = _env_int("PLR_EYE_CROP_OUTPUT_SIZE", 224, 32)
        metadata = {
            "crop_mode": "detect_fixed_scale",
            "selected_eye": EYE_LABELS[led_index],
            "detector": "opencv_haar_eye",
            "input_frame_size": {"width": frame_width, "height": frame_height},
            "output_frame_size": {"width": output_size, "height": output_size},
            "fixed_source_box_size_px": fixed_size,
            "source_to_output_scale": round(output_size / float(fixed_size), 8),
            "scale_is_constant": True,
            "frames_seen": len(detections_by_frame),
            "frames_written": frames_written,
            "detected_frames": len(detected),
            "interpolated_center_frames": len(detections_by_frame) - len(detected),
            "median_center_px": {
                "x": round(float(median(tracked_x)), 3),
                "y": round(float(median(tracked_y)), 3),
            },
            "normalized_detection_search_roi": self._normalized_roi_dict(
                self.detection_search_rois[led_index]
            ),
        }
        return str(output), metadata

    def _crop_static(self, video_path: str, led_index: int) -> tuple[str, dict]:
        cv2 = self._cv2()
        source = Path(video_path)
        cap, fps, frame_width, frame_height = self._open_video(cv2, source)
        frame_count = 0
        while True:
            ok, _frame = cap.read()
            if not ok:
                break
            frame_count += 1
        cap.release()
        if frame_count == 0:
            raise RuntimeError(f"Video contains no decodable frames: {source}")
        x, y, width, height = self._normalized_to_pixel_roi(
            self.rois[led_index],
            frame_width,
            frame_height,
        )
        explicit_size = os.environ.get("PLR_EYE_FIXED_BOX_SIZE_PX")
        fixed_size = int(explicit_size) if explicit_size else min(width, height)
        fixed_size = self._valid_even_size(fixed_size, frame_width, frame_height)
        center_x = x + width / 2.0
        center_y = y + height / 2.0
        box = self._square_at_center(
            center_x,
            center_y,
            fixed_size,
            frame_width,
            frame_height,
        )
        boxes = [box] * frame_count
        output, frames_written = self._write_crops(
            cv2,
            source,
            led_index,
            fps,
            frame_width,
            frame_height,
            boxes,
        )
        output_size = _env_int("PLR_EYE_CROP_OUTPUT_SIZE", 224, 32)
        return str(output), {
            "crop_mode": "static_fixed_scale",
            "selected_eye": EYE_LABELS[led_index],
            "input_frame_size": {"width": frame_width, "height": frame_height},
            "output_frame_size": {"width": output_size, "height": output_size},
            "fixed_source_box": self._pixel_roi_dict(box),
            "fixed_source_box_size_px": fixed_size,
            "source_to_output_scale": round(output_size / float(fixed_size), 8),
            "scale_is_constant": True,
            "frames_seen": frame_count,
            "frames_written": frames_written,
        }

    def _write_crops(
        self,
        cv2,
        source: Path,
        led_index: int,
        fps: float,
        frame_width: int,
        frame_height: int,
        boxes: list[tuple[int, int, int, int]],
    ) -> tuple[Path, int]:
        output_size = _env_int("PLR_EYE_CROP_OUTPUT_SIZE", 224, 32)
        output = self.output_dir / f"{EYE_LABELS[led_index]}_eye_full.mp4"
        fourcc = cv2.VideoWriter_fourcc(*os.environ.get("PLR_CROP_FOURCC", "mp4v")[:4])
        writer = cv2.VideoWriter(str(output), fourcc, fps, (output_size, output_size))
        if not writer.isOpened():
            raise RuntimeError(f"Cannot create cropped eye video: {output}")

        save_debug = _env_bool("PLR_SAVE_EYE_DEBUG_VIDEO", False)
        debug_output = self.output_dir / f"{EYE_LABELS[led_index]}_eye_debug.mp4"
        debug_writer = (
            cv2.VideoWriter(str(debug_output), fourcc, fps, (frame_width, frame_height))
            if save_debug
            else None
        )
        cap = cv2.VideoCapture(str(source))
        frames_written = 0
        try:
            for box in boxes:
                ok, frame = cap.read()
                if not ok:
                    break
                x, y, size, _ = box
                crop = frame[y : y + size, x : x + size]
                crop = cv2.resize(crop, (output_size, output_size), interpolation=cv2.INTER_LINEAR)
                writer.write(crop)
                frames_written += 1
                if debug_writer is not None:
                    cv2.rectangle(frame, (x, y), (x + size, y + size), (0, 255, 0), 2)
                    debug_writer.write(frame)
        finally:
            cap.release()
            writer.release()
            if debug_writer is not None:
                debug_writer.release()
        return output, frames_written

    @staticmethod
    def _open_video(cv2, source: Path):
        cap = cv2.VideoCapture(str(source))
        if not cap.isOpened():
            raise IOError(f"Cannot open video for eye crop: {source}")
        fps = float(cap.get(cv2.CAP_PROP_FPS)) or 24.0
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if width <= 0 or height <= 0:
            cap.release()
            raise RuntimeError(f"Cannot read frame size for eye crop: {source}")
        return cap, fps, width, height

    @staticmethod
    def _expanded_size(box: tuple[int, int, int, int], padding: float) -> int:
        return max(2, int(round(max(box[2], box[3]) * (1.0 + 2.0 * padding))))

    @staticmethod
    def _valid_even_size(size: int, frame_width: int, frame_height: int) -> int:
        size = min(max(2, int(size)), frame_width, frame_height)
        return size if size % 2 == 0 else max(2, size - 1)

    @staticmethod
    def _square_at_center(
        center_x: float,
        center_y: float,
        size: int,
        frame_width: int,
        frame_height: int,
    ) -> tuple[int, int, int, int]:
        x = min(max(0, int(round(center_x - size / 2.0))), frame_width - size)
        y = min(max(0, int(round(center_y - size / 2.0))), frame_height - size)
        return x, y, size, size

    @staticmethod
    def _moving_median(values, window: int):
        import numpy as np

        radius = max(0, int(window) // 2)
        return np.asarray(
            [
                np.median(values[max(0, i - radius) : min(len(values), i + radius + 1)])
                for i in range(len(values))
            ],
            dtype=float,
        )

    @staticmethod
    def _select_best_eye_box(detections):
        if not detections:
            return None
        return max(detections, key=lambda box: box[2] * box[3])

    @staticmethod
    def _select_eye_box(detections, target_eye: str):
        if not detections:
            return None
        key = lambda box: box[0] + box[2] / 2.0
        return min(detections, key=key) if target_eye == "left" else max(detections, key=key)

    @staticmethod
    def _expand_to_square(box, frame_width: int, frame_height: int, padding: float):
        size = EyeCropper._valid_even_size(
            EyeCropper._expanded_size(box, padding),
            frame_width,
            frame_height,
        )
        return EyeCropper._square_at_center(
            box[0] + box[2] / 2.0,
            box[1] + box[3] / 2.0,
            size,
            frame_width,
            frame_height,
        )

    @staticmethod
    def _dedupe_boxes(boxes):
        kept = []
        for box in sorted(boxes, key=lambda item: item[2] * item[3], reverse=True):
            if all(EyeCropper._intersection_over_union(box, other) < 0.35 for other in kept):
                kept.append(box)
        return kept

    @staticmethod
    def _intersection_over_union(first, second):
        ax1, ay1, aw, ah = first
        bx1, by1, bw, bh = second
        ax2, ay2 = ax1 + aw, ay1 + ah
        bx2, by2 = bx1 + bw, by1 + bh
        intersection = max(0, min(ax2, bx2) - max(ax1, bx1)) * max(
            0, min(ay2, by2) - max(ay1, by1)
        )
        union = aw * ah + bw * bh - intersection
        return intersection / union if union else 0.0

    @staticmethod
    def _normalized_to_pixel_roi(roi, frame_width: int, frame_height: int):
        x, y, width, height = roi
        px = int(round(x * frame_width))
        py = int(round(y * frame_height))
        pw = max(1, int(round(width * frame_width)))
        ph = max(1, int(round(height * frame_height)))
        pw = min(pw, frame_width - px)
        ph = min(ph, frame_height - py)
        return px, py, pw, ph

    @staticmethod
    def _normalized_roi_dict(roi):
        return dict(zip(("x", "y", "width", "height"), roi))

    @staticmethod
    def _pixel_roi_dict(roi):
        return dict(zip(("x", "y", "width", "height"), roi))

    @staticmethod
    def _cv2():
        try:
            import cv2
        except ImportError as exc:
            raise RuntimeError("OpenCV is required for eye cropping") from exc
        return cv2
