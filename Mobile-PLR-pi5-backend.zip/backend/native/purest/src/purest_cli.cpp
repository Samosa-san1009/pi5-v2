// plr_purest -- run PuReST (or PuRe) over every frame of an eye video.
//
// Replaces the old fixed-path "PupilDetection" binary. Input and output paths
// are arguments, so several analyses can run at once and nothing outside the
// session workspace is touched.
//
// Output CSV (one row per decoded frame, frame numbers start at 0):
//   Frame,Valid,Confidence,Outline_confidence,Diameter_px,Minor_px,
//   Center_x,Center_y,Angle_deg
// The first four column names match the old binary, so older tooling that
// reads Frame/Valid/Confidence/Diameter_px keeps working.
//
// The pupil-detection algorithms are by Thiago Santini et al. and are licensed
// for non-commercial use only; see third_party/pupil-detection-methods.

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>

#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>

#include "PuRe.h"
#include "PuReST.h"

namespace {

struct Options {
    std::string input;
    std::string output;
    std::string algorithm = "purest";
    float min_pupil_mm = -1.0f;
    float max_pupil_mm = -1.0f;
    long max_frames = -1;
    int progress_every = 0;
};

void usage(const char *argv0) {
    std::cerr
        << "usage: " << argv0 << " --input VIDEO --output CSV [options]\n"
        << "  --algorithm purest|pure   tracking PuReST (default) or per-frame PuRe\n"
        << "  --min-pupil-mm F          PuRe minimum pupil diameter assumption\n"
        << "  --max-pupil-mm F          PuRe maximum pupil diameter assumption\n"
        << "  --max-frames N            stop after N frames (testing)\n"
        << "  --progress N              print 'progress <frame>' to stderr every N frames\n";
}

bool parse(int argc, char **argv, Options &opt) {
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto next = [&](const char *name) -> const char * {
            if (i + 1 >= argc) {
                std::cerr << "missing value for " << name << "\n";
                std::exit(2);
            }
            return argv[++i];
        };
        if (arg == "--input") opt.input = next("--input");
        else if (arg == "--output") opt.output = next("--output");
        else if (arg == "--algorithm") opt.algorithm = next("--algorithm");
        else if (arg == "--min-pupil-mm") opt.min_pupil_mm = std::strtof(next("--min-pupil-mm"), nullptr);
        else if (arg == "--max-pupil-mm") opt.max_pupil_mm = std::strtof(next("--max-pupil-mm"), nullptr);
        else if (arg == "--max-frames") opt.max_frames = std::strtol(next("--max-frames"), nullptr, 10);
        else if (arg == "--progress") opt.progress_every = std::atoi(next("--progress"));
        else if (arg == "--help" || arg == "-h") { usage(argv[0]); std::exit(0); }
        else {
            std::cerr << "unknown argument: " << arg << "\n";
            return false;
        }
    }
    if (opt.input.empty() || opt.output.empty()) return false;
    if (opt.algorithm != "purest" && opt.algorithm != "pure") {
        std::cerr << "--algorithm must be 'purest' or 'pure'\n";
        return false;
    }
    return true;
}

}  // namespace

int main(int argc, char **argv) {
    Options opt;
    if (!parse(argc, argv, opt)) {
        usage(argv[0]);
        return 2;
    }

    cv::VideoCapture cap(opt.input);
    if (!cap.isOpened()) {
        std::cerr << "cannot open video: " << opt.input << "\n";
        return 3;
    }

    std::unique_ptr<PuRe> detector;
    if (opt.algorithm == "purest") detector.reset(new PuReST());
    else detector.reset(new PuRe());
    if (opt.min_pupil_mm > 0) detector->minPupilDiameterMM = opt.min_pupil_mm;
    if (opt.max_pupil_mm > 0) detector->maxPupilDiameterMM = opt.max_pupil_mm;

    // Write to a temporary file and rename at the end, so a crash never leaves
    // a truncated CSV that looks complete.
    const std::string tmp_path = opt.output + ".partial";
    std::ofstream out(tmp_path);
    if (!out) {
        std::cerr << "cannot write: " << tmp_path << "\n";
        return 4;
    }
    out << "Frame,Valid,Confidence,Outline_confidence,Diameter_px,Minor_px,"
           "Center_x,Center_y,Angle_deg\n";
    out << std::fixed << std::setprecision(4);

    cv::Mat frame, gray;
    long index = 0;
    const auto started = std::chrono::steady_clock::now();
    while (cap.read(frame)) {
        if (opt.max_frames >= 0 && index >= opt.max_frames) break;
        if (frame.channels() == 3) cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        else if (frame.channels() == 4) cv::cvtColor(frame, gray, cv::COLOR_BGRA2GRAY);
        else gray = frame;

        Pupil pupil;
        detector->run(gray, pupil);

        const bool has_outline = pupil.size.width > 0 && pupil.size.height > 0 &&
                                 pupil.center.x > 0 && pupil.center.y > 0;
        const float confidence = pupil.confidence;
        const bool valid = has_outline && confidence > 0.0f;
        const float major = has_outline ? std::max(pupil.size.width, pupil.size.height) : NAN;
        const float minor = has_outline ? std::min(pupil.size.width, pupil.size.height) : NAN;

        out << index << ',' << (valid ? 1 : 0) << ',' << confidence << ','
            << pupil.outline_confidence << ',';
        if (has_outline) {
            out << major << ',' << minor << ',' << pupil.center.x << ',' << pupil.center.y
                << ',' << pupil.angle;
        } else {
            out << ",,,,";
        }
        out << '\n';

        ++index;
        if (opt.progress_every > 0 && index % opt.progress_every == 0) {
            std::cerr << "progress " << index << std::endl;
        }
    }
    out.close();
    if (!out) {
        std::cerr << "error while writing " << tmp_path << "\n";
        return 5;
    }
    if (index == 0) {
        std::cerr << "no frames decoded from " << opt.input << "\n";
        std::remove(tmp_path.c_str());
        return 6;
    }
    if (std::rename(tmp_path.c_str(), opt.output.c_str()) != 0) {
        std::cerr << "cannot rename " << tmp_path << " -> " << opt.output << "\n";
        return 7;
    }

    const double seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - started).count();
    std::cerr << "done frames=" << index << " seconds=" << seconds
              << " fps=" << (seconds > 0 ? index / seconds : 0.0) << std::endl;
    return 0;
}
