"""Mobile PLR server for Raspberry Pi 5.

Start:  python server.py          (or the plr.service systemd unit)

The existing Eyezer app works unchanged: enter the Pi's IP (shown on the TFT)
and start a session. Endpoints used by the app keep the same request and
response shapes:

    GET  /health   GET /status   POST /session   GET /results   GET /video

Additional endpoints:

    GET  /settings                 device settings (pins, LED power, camera...)
    POST /settings                 partial update, e.g. {"leds": {"left": {"power_pct": 80}}}
    POST /settings/reset
    GET  /analyzers                registered pupil analyzers and readiness
    POST /session/stop             abort the running session
    GET  /preview.jpg              latest IR frame (lores stream)
    GET  /stream.mjpg              live IR stream for a browser
    POST /leds/test                {"side": "left", "hex": "#FFFFFF", "intensity": 50, "duration": 0.2}
    POST /selftest                 flash each LED, report optical detection and latency
    GET  /time                     NTP / RTC / clock status
    GET  /sessions                 recorded sessions
    GET  /sessions/<id>/results    results of any session (?analyzer=name for re-analyses)
    GET  /sessions/<id>/video
    POST /sessions/<id>/reanalyze  {"analyzer": "resnet18"} - same video, another model
    POST /restart                  restart the service (applies camera/pin changes)
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import re
import signal
import statistics
import sys
import threading
import time
import traceback
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_file
from werkzeug.exceptions import HTTPException

sys.path.insert(0, str(Path(__file__).resolve().parent))

from plr import __version__, analyzers, timebase  # noqa: E402
from plr.analysis.worker import run_analysis  # noqa: E402
from plr.camera_service import create_camera  # noqa: E402
from plr.config_adapter import adapt  # noqa: E402
from plr.display import TftDisplay  # noqa: E402
from plr.endstops import EndstopMonitor  # noqa: E402
from plr.leds import LedController  # noqa: E402
from plr.orchestrator import SessionRecorder, _sleep_until  # noqa: E402
from plr.settings import REPO_ROOT, SettingsStore  # noqa: E402

logging.basicConfig(
    level=getattr(logging, os.environ.get("PLR_LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
LOG = logging.getLogger("plr.server")
MOCK = os.environ.get("PLR_HARDWARE", "").lower() == "mock"
SESSIONS_ROOT = Path(os.environ.get("PLR_SESSIONS_ROOT", REPO_ROOT / "sessions"))

app = Flask(__name__)
SETTINGS = SettingsStore()
STATE_LOCK = threading.Lock()
SESSION_LOCK = threading.Lock()        # held for the whole recording + analysis
ABORT = threading.Event()
STATE: dict = {
    "stage": "idle", "started_at": None, "ended_at": None,
    "error": None, "error_type": None, "error_stage": None, "error_details": None, "error_log_path": None,
    "session_id": None, "session_dir": None, "log_path": None, "video_path": None,
    "pupilogram_path": None, "metrics_path": None, "progress": None, "session_status": None,
    "analyzer": None, "warnings": [],
}
REANALYSIS: dict[str, dict] = {}
BUSY = {"reason": None}                # what currently holds SESSION_LOCK
RIG: dict = {}


# ── hardware ────────────────────────────────────────────────────────────────

def build_rig():
    settings = SETTINGS.get()
    analyzers.load_all(settings)
    leds = LedController(settings["leds"])
    mock_backend = leds.backend if leds.is_mock else None
    endstops = EndstopMonitor(settings["endstops"], mock_led_backend=mock_backend)
    endstops.start()
    camera = create_camera(settings["camera"], leds=leds)
    camera.start()
    display = TftDisplay(settings["display"], camera, state_provider=display_state, leds=leds)
    display.start()
    RIG.update(leds=leds, endstops=endstops, camera=camera, display=display)
    for name, part in (("LEDs", leds), ("endstops", endstops)):
        if getattr(part, "error", None):
            LOG.warning("%s: %s", name, part.error)


def display_state() -> dict:
    with STATE_LOCK:
        return {"stage": STATE["stage"], "port": SETTINGS.section("server")["port"]}


def shutdown(*_):
    try:
        ABORT.set()
        if RIG.get("leds"):
            RIG["leds"].close()
        if RIG.get("display"):
            RIG["display"].stop()
        if RIG.get("camera"):
            RIG["camera"].stop()
        if RIG.get("endstops"):
            RIG["endstops"].close()
    except Exception:
        pass


def set_state(**changes):
    with STATE_LOCK:
        STATE.update(changes)


def state_copy() -> dict:
    with STATE_LOCK:
        return json.loads(json.dumps(STATE, default=str))


# ── sessions ────────────────────────────────────────────────────────────────

def make_session_paths(participant: dict) -> dict:
    stamp, clock_source = timebase.session_datetime()
    name = re.sub(r"[^a-zA-Z0-9_-]+", "_", str(participant.get("name") or "anon")).strip("_") or "anon"
    session_id = f"{stamp.strftime('%Y%m%d_%H%M%S_%f')}_{name}"
    session_dir = SESSIONS_ROOT / session_id
    session_dir.mkdir(parents=True, exist_ok=False)
    return {
        "session_id": session_id, "session_dir": session_dir, "wall_clock_source": clock_source,
        "video": session_dir / "full_video.mp4", "events": session_dir / "events.json",
        "pupilogram": session_dir / "pupilogram.json", "metrics": session_dir / "metrics.json",
        "log": session_dir / "session.log", "manifest": session_dir / "manifest.json",
    }


def session_logger(paths: dict) -> logging.Logger:
    logger = logging.getLogger(f"plr.session.{paths['session_id']}")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    handler = logging.FileHandler(paths["log"], encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.handlers = [handler]
    return logger


def write_manifest(paths: dict, config: dict, settings: dict):
    manifest = {
        "session_id": paths["session_id"],
        "software_version": __version__,
        "mock_hardware": MOCK or RIG["leds"].is_mock,
        "wall_clock_source": paths["wall_clock_source"],
        "clock_status": timebase.clock_status(),
        "config": {k: v for k, v in config.items() if k != "request"},
        "request": config.get("request"),
        "settings": settings,
        "hardware": {
            "leds": RIG["leds"].status(),
            "endstops": RIG["endstops"].status(),
            "camera": RIG["camera"].status(),
        },
    }
    paths["manifest"].write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")


def analysis_job(session_id, session_dir, log_path, analyzer, options, settings, participant, suffix=""):
    return {
        "session_id": session_id, "session_dir": str(session_dir), "log_path": str(log_path),
        "analyzer": analyzer, "analyzer_options": options, "settings": settings,
        "participant": participant, "output_suffix": suffix,
        "cpus": settings["analysis"].get("cpus"), "nice": settings["analysis"].get("nice", 10),
    }


def run_session(config: dict, paths: dict, settings: dict):
    logger = session_logger(paths)
    try:
        write_manifest(paths, config, settings)
        set_state(stage="recording", started_at=time.time())
        recorder = SessionRecorder(config, paths, RIG["camera"], RIG["leds"], RIG["endstops"],
                                   settings["endstops"], logger, ABORT)
        timeline = recorder.run()["timeline"]
        set_state(warnings=timeline["warnings"])
        for message in timeline["warnings"]:
            logger.warning(message)
        logger.info("Optical timing: %s", json.dumps(timeline["optical"]))

        set_state(stage="analysis", progress={"completed": 0, "total": 2, "fraction": 0.0})

        def on_progress(msg):
            done = 2 if msg.get("stage") == "done" else (0 if msg.get("eye") == "left" else 1)
            set_state(progress={"completed": done, "total": 2, "item": msg.get("eye"),
                                "item_status": msg.get("stage"), "fraction": msg.get("fraction")})

        job = analysis_job(paths["session_id"], paths["session_dir"], paths["log"], config["analyzer"],
                           config["analyzer_options"], settings, config.get("participant"))
        result = run_analysis(job, on_progress=on_progress)
        set_state(stage="done", ended_at=time.time(), session_status=result["status"], progress=None)
        logger.info("Session complete: %s", result["status"])
    except Exception as exc:
        failed = state_copy()["stage"]
        logger.exception("Session failed at stage=%s", failed)
        traceback.print_exc()
        set_state(stage="error", ended_at=time.time(), error=str(exc) or type(exc).__name__,
                  error_type=type(exc).__name__, error_stage=failed,
                  error_details=getattr(exc, "details", None), error_log_path=str(paths["log"]))
    finally:
        try:
            RIG["leds"].all_off()
        except Exception:
            pass
        for handler in list(logger.handlers):
            handler.close()
            logger.removeHandler(handler)
        BUSY["reason"] = None
        SESSION_LOCK.release()


def session_dir_for(session_id: str) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", session_id):
        raise ValueError("invalid session id")
    path = SESSIONS_ROOT / session_id
    if not path.is_dir():
        raise FileNotFoundError(session_id)
    return path


def results_payload(session_dir: Path, analyzer: str | None = None):
    suffix = f"_{analyzer}" if analyzer else ""
    pupilogram_path = session_dir / f"pupilogram{suffix}.json"
    metrics_path = session_dir / f"metrics{suffix}.json"
    if not pupilogram_path.is_file() or not metrics_path.is_file():
        return None
    pupilogram = json.loads(pupilogram_path.read_text(encoding="utf-8"))
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    return {
        "schema_version": 5,
        "status": metrics["status"],
        "session_id": metrics["session_id"],
        "video": {"path": str(session_dir / "full_video.mp4"), "url": f"/sessions/{session_dir.name}/video"},
        "pupilogram": pupilogram,
        "metrics": metrics,
    }


# ── routes: app contract ────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    leds, camera, endstops = RIG["leds"].status(), RIG["camera"].status(), RIG["endstops"].status()
    state = state_copy()
    error = None
    if state.get("error"):
        error = {k: state.get(k) for k in ("error", "error_type", "error_stage", "error_details", "error_log_path")}
    return jsonify({
        "ok": bool(leds["ready"] and camera["running"]),
        "version": __version__,
        "mock_hardware": MOCK,
        "stage": state["stage"],
        "error": error,
        "hardware": {
            "camera": camera,
            "leds": leds,
            "led_control": leds["ready"],
            "endstops": endstops,
            "display": RIG["display"].status(),
            "clock": timebase.clock_status(),
        },
        "analyzers": analyzers.status_all(),
    })


@app.route("/session", methods=["POST"])
def start_session():
    if not SESSION_LOCK.acquire(blocking=False):
        return jsonify({"ok": False, "error": f"busy: {BUSY['reason'] or 'session running'}",
                        "stage": state_copy()["stage"]}), 409
    BUSY["reason"] = "session running"
    started = False
    try:
        settings = SETTINGS.get()
        try:
            config = adapt(request.get_json(silent=True) or {}, settings, set(analyzers.registry()))
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc), "error_type": type(exc).__name__,
                            "error_stage": "request_validation"}), 400
        leds = RIG["leds"]
        if not leds.ready:
            return jsonify({"ok": False, "stage": "hardware_initialization", "error": leds.error,
                            "hardware": {"leds": leds.status(), "led_control": False}}), 503
        if leds.is_mock and not (MOCK or os.environ.get("PLR_ALLOW_MOCK") == "1"):
            return jsonify({"ok": False, "error": "refusing a PLR session with simulated LEDs"}), 503
        if not RIG["camera"].status()["running"]:
            return jsonify({"ok": False, "stage": "hardware_initialization",
                            "error": f"camera not running: {RIG['camera'].error}"}), 503
        analyzer_status = analyzers.status_all().get(config["analyzer"], {})
        if not analyzer_status.get("ready", False):
            return jsonify({"ok": False, "stage": "model_initialization",
                            "error": f"analyzer {config['analyzer']!r} is not ready",
                            "error_details": analyzer_status}), 503
        paths = make_session_paths(config.get("participant") or {})
        ABORT.clear()
        set_state(stage="starting", started_at=None, ended_at=None, error=None, error_type=None,
                  error_stage=None, error_details=None, error_log_path=None, progress=None,
                  session_status=None, warnings=[], analyzer=config["analyzer"],
                  session_id=paths["session_id"], session_dir=str(paths["session_dir"]),
                  log_path=str(paths["log"]), video_path=str(paths["video"]),
                  pupilogram_path=str(paths["pupilogram"]), metrics_path=str(paths["metrics"]))
        threading.Thread(target=run_session, args=(config, paths, settings), daemon=True,
                         name=f"session-{paths['session_id']}").start()
        started = True
        return jsonify({"ok": True, "stage": "starting", "session_id": paths["session_id"],
                        "analyzer": config["analyzer"]}), 202
    finally:
        if not started:
            BUSY["reason"] = None
            SESSION_LOCK.release()


@app.route("/session/stop", methods=["POST"])
def stop_session():
    ABORT.set()
    return jsonify({"ok": True, "stage": state_copy()["stage"]})


@app.route("/status", methods=["GET"])
def status():
    return jsonify(state_copy())


@app.route("/results", methods=["GET"])
def results():
    state = state_copy()
    if not state.get("session_dir"):
        return jsonify({"error": "not ready", "stage": state["stage"]}), 404
    payload = results_payload(Path(state["session_dir"]))
    if payload is None:
        return jsonify({"error": "not ready", "stage": state["stage"]}), 404
    payload["video"]["url"] = "/video"
    return jsonify(payload)


@app.route("/video", methods=["GET"])
def video():
    path = state_copy().get("video_path")
    if not path or not Path(path).is_file() or RIG["camera"].recording:
        return jsonify({"error": "not ready", "stage": state_copy()["stage"]}), 404
    return send_file(path, mimetype="video/mp4", as_attachment=True)


# ── routes: settings, analyzers, sessions ───────────────────────────────────

@app.route("/settings", methods=["GET"])
def get_settings():
    return jsonify(SETTINGS.get())


@app.route("/settings", methods=["POST"])
def post_settings():
    patch = request.get_json(silent=True) or {}
    before = SETTINGS.get()
    try:
        after = SETTINGS.update(patch)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    applied, restart = [], []
    if after["leds"] != before["leds"]:
        if SESSION_LOCK.acquire(blocking=False):
            try:
                RIG["leds"].reconfigure(after["leds"])
                applied.append("leds")
            finally:
                SESSION_LOCK.release()
        else:
            restart.append("leds (session running; restart or re-save after it ends)")
    if after["analysis"] != before["analysis"]:
        analyzers.load_all(after)
        applied.append("analysis")
    for section in ("endstops", "camera", "display", "server"):
        if after[section] != before[section]:
            restart.append(section)
    for section in ("eye_crop", "session"):
        if after[section] != before[section]:
            applied.append(section)
    return jsonify({"ok": True, "applied": applied, "restart_required": restart, "settings": after})


@app.route("/settings/reset", methods=["POST"])
def reset_settings():
    return jsonify({"ok": True, "settings": SETTINGS.reset(), "restart_required": ["all"]})


@app.route("/analyzers", methods=["GET"])
def list_analyzers():
    analysis = SETTINGS.section("analysis")
    return jsonify({"default": analysis.get("default_analyzer"), "forced": analysis.get("force_analyzer"),
                    "analyzers": analyzers.status_all()})


@app.route("/sessions", methods=["GET"])
def list_sessions():
    out = []
    if SESSIONS_ROOT.is_dir():
        for path in sorted(SESSIONS_ROOT.iterdir(), reverse=True)[:200]:
            if not path.is_dir():
                continue
            entry = {"session_id": path.name, "has_video": (path / "full_video.mp4").is_file(),
                     "results": sorted(p.stem.replace("metrics", "").lstrip("_") or "default"
                                       for p in path.glob("metrics*.json"))}
            try:
                metrics = json.loads((path / "metrics.json").read_text())
                entry["status"] = metrics.get("status")
                entry["analyzer"] = metrics.get("analyzer")
            except Exception:
                pass
            out.append(entry)
    return jsonify({"sessions": out})


@app.route("/sessions/<session_id>/results", methods=["GET"])
def session_results(session_id):
    try:
        path = session_dir_for(session_id)
    except (ValueError, FileNotFoundError):
        return jsonify({"error": "unknown session"}), 404
    analyzer = request.args.get("analyzer")
    payload = results_payload(path, analyzer if analyzer and analyzer != "default" else None)
    if payload is None:
        return jsonify({"error": "not ready", "job": REANALYSIS.get(f"{session_id}:{analyzer}")}), 404
    return jsonify(payload)


@app.route("/sessions/<session_id>/video", methods=["GET"])
def session_video(session_id):
    try:
        path = session_dir_for(session_id) / "full_video.mp4"
    except (ValueError, FileNotFoundError):
        return jsonify({"error": "unknown session"}), 404
    if not path.is_file():
        return jsonify({"error": "no video"}), 404
    return send_file(path, mimetype="video/mp4", as_attachment=True)


@app.route("/sessions/<session_id>/reanalyze", methods=["POST"])
def reanalyze(session_id):
    body = request.get_json(silent=True) or {}
    name = str(body.get("analyzer") or "").lower()
    if name not in analyzers.registry():
        return jsonify({"ok": False, "error": f"unknown analyzer {name!r}",
                        "available": sorted(analyzers.registry())}), 400
    try:
        session_dir = session_dir_for(session_id)
    except (ValueError, FileNotFoundError):
        return jsonify({"ok": False, "error": "unknown session"}), 404
    if not (session_dir / "events.json").is_file():
        return jsonify({"ok": False, "error": "session has no recorded timeline"}), 409
    if not SESSION_LOCK.acquire(blocking=False):
        return jsonify({"ok": False, "error": f"busy: {BUSY['reason'] or 'another operation is running'}"}), 409
    BUSY["reason"] = f"re-analysing {session_id} with {name}"
    key = f"{session_id}:{name}"
    REANALYSIS[key] = {"state": "running", "started_at": time.time(), "progress": None}
    settings = SETTINGS.get()
    options = {"preprocess": str(body.get("pupilPreprocess", "imagenet"))}

    def work():
        try:
            job = analysis_job(session_id, session_dir, session_dir / "session.log", name, options, settings,
                               None, suffix=f"_{name}")
            result = run_analysis(job, on_progress=lambda m: REANALYSIS[key].update(progress=m))
            REANALYSIS[key].update(state="done", status=result["status"], ended_at=time.time())
        except Exception as exc:
            REANALYSIS[key].update(state="error", error=str(exc), ended_at=time.time())
        finally:
            BUSY["reason"] = None
            SESSION_LOCK.release()

    threading.Thread(target=work, daemon=True).start()
    return jsonify({"ok": True, "job": key, "results_url": f"/sessions/{session_id}/results?analyzer={name}"}), 202


# ── routes: live view, LEDs, diagnostics ────────────────────────────────────

def _jpeg(grey) -> bytes:
    import cv2

    ok, buf = cv2.imencode(".jpg", grey, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
    return buf.tobytes() if ok else b""


@app.route("/preview.jpg", methods=["GET"])
def preview():
    item = RIG["camera"].sink.wait(0, timeout=2.0)
    if item is None:
        return jsonify({"error": "no frame yet"}), 503
    return Response(_jpeg(item[1]), mimetype="image/jpeg")


@app.route("/stream.mjpg", methods=["GET"])
def stream():
    fps = min(15.0, max(1.0, float(request.args.get("fps", 10))))

    def frames():
        seq = 0
        while True:
            item = RIG["camera"].sink.wait(seq, timeout=2.0)
            if item is None:
                continue
            seq, grey, _ = item
            yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + _jpeg(grey) + b"\r\n"
            time.sleep(1.0 / fps)

    return Response(frames(), mimetype="multipart/x-mixed-replace; boundary=frame")


def _flash_and_measure(side: str, hex_color: str, intensity: float, duration_s: float, power=None) -> dict:
    leds, endstops = RIG["leds"], RIG["endstops"]
    rgb = leds.rgb_for(side, hex_color, intensity, power)
    on = leds.set({side: rgb})
    _sleep_until(on["end_ns"] + int(duration_s * 1e9))
    off = leds.set({side: (0, 0, 0)})
    time.sleep(0.05)
    out = {"side": side, "rgb": list(rgb), "optical_detected": False}
    if endstops.ready:
        window_end = off["end_ns"] + 50_000_000
        max_latency = int(float(SETTINGS.section("endstops")["max_latency_ms"]) * 1e6)
        own = [p for p in endstops.pulses(side, on["start_ns"] - 1_000_000, window_end)
               if p["onset_ns"] <= on["end_ns"] + max_latency]
        other = "right" if side == "left" else "left"
        cross = endstops.pulses(other, on["start_ns"] - 1_000_000, window_end) if other in endstops.sides else []
        if own:
            pulse = own[0]
            out.update(optical_detected=True,
                       latency_ms=round((pulse["onset_ns"] - on["end_ns"]) / 1e6, 4),
                       measured_duration_ms=round((pulse["offset_ns"] - pulse["onset_ns"]) / 1e6, 3),
                       raw_pulses=pulse["raw_pulses"])
        out["crosstalk_pulses_on_other_sensor"] = len(cross)
    return out


@app.route("/leds/test", methods=["POST"])
def led_test():
    body = request.get_json(silent=True) or {}
    side = body.get("side", "left")
    if side not in ("left", "right", "both"):
        return jsonify({"ok": False, "error": "side must be left, right or both"}), 400
    if not RIG["leds"].ready:
        return jsonify({"ok": False, "error": RIG["leds"].error}), 503
    if not SESSION_LOCK.acquire(blocking=False):
        return jsonify({"ok": False, "error": f"busy: {BUSY['reason'] or 'another operation is running'}"}), 409
    try:
        sides = ["left", "right"] if side == "both" else [side]
        duration = min(5.0, max(0.02, float(body.get("duration", 0.2))))
        results = [_flash_and_measure(s, body.get("hex", "#FFFFFF"), float(body.get("intensity", 100)),
                                      duration, body.get("power")) for s in sides]
        return jsonify({"ok": True, "results": results})
    finally:
        SESSION_LOCK.release()


@app.route("/selftest", methods=["POST"])
def selftest():
    body = request.get_json(silent=True) or {}
    repeats = max(1, min(20, int(body.get("repeats", 5))))
    intensity = float(body.get("intensity", 100))
    if not RIG["leds"].ready:
        return jsonify({"ok": False, "error": RIG["leds"].error}), 503
    if not SESSION_LOCK.acquire(blocking=False):
        return jsonify({"ok": False, "error": f"busy: {BUSY['reason'] or 'another operation is running'}"}), 409
    try:
        report = {"endstops": RIG["endstops"].status(), "idle_warnings": RIG["endstops"].recheck_idle(), "sides": {}}
        for side in ("left", "right"):
            trials = []
            for _ in range(repeats):
                trials.append(_flash_and_measure(side, "#FFFFFF", intensity, 0.1))
                time.sleep(0.25)
            latencies = [t["latency_ms"] for t in trials if t.get("optical_detected")]
            report["sides"][side] = {
                "detected": f"{len(latencies)}/{repeats}",
                "latency_ms_median": round(statistics.median(latencies), 4) if latencies else None,
                "latency_ms_range": [min(latencies), max(latencies)] if latencies else None,
                "crosstalk_trials": sum(1 for t in trials if t.get("crosstalk_pulses_on_other_sensor")),
            }
        report["ok"] = all(v["detected"] == f"{repeats}/{repeats}" for v in report["sides"].values())
        return jsonify(report)
    finally:
        SESSION_LOCK.release()


@app.route("/time", methods=["GET"])
def time_status():
    return jsonify({**timebase.clock_status(), "anchor": timebase.anchor()})


@app.route("/restart", methods=["POST"])
def restart():
    if not SESSION_LOCK.acquire(blocking=False):
        return jsonify({"ok": False, "error": f"busy: {BUSY['reason'] or 'another operation is running'}"}), 409

    def later():
        time.sleep(0.5)
        shutdown()
        os._exit(0)  # systemd (Restart=always) starts a fresh process

    threading.Thread(target=later, daemon=True).start()
    return jsonify({"ok": True, "message": "restarting"})


@app.errorhandler(Exception)
def unexpected(exc):
    if isinstance(exc, HTTPException):
        return exc
    request_id = f"req_{time.time_ns()}"
    LOG.exception("Unhandled error request_id=%s %s %s", request_id, request.method, request.path)
    return jsonify({"ok": False, "error": str(exc) or "internal error", "error_type": type(exc).__name__,
                    "request_id": request_id}), 500


def main():
    SESSIONS_ROOT.mkdir(parents=True, exist_ok=True)
    build_rig()
    atexit.register(shutdown)
    signal.signal(signal.SIGTERM, lambda *_: (shutdown(), os._exit(0)))
    port = int(os.environ.get("PLR_PORT", SETTINGS.section("server")["port"]))
    LOG.info("Mobile PLR %s listening on 0.0.0.0:%d (mock=%s)", __version__, port, MOCK)
    app.run(host="0.0.0.0", port=port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
