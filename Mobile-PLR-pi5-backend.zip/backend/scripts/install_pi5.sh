#!/usr/bin/env bash
# Mobile PLR installer for Raspberry Pi 5 (64-bit Raspberry Pi OS Bookworm).
#
#   cd ~/Documents/Mobile-PLR
#   bash backend/scripts/install_pi5.sh            # RTC_MODEL=ds3231 or none to change
#
# Safe to re-run after every `git pull`. It:
#   1. installs APT packages (camera, lgpio, OpenCV dev, ffmpeg, cmake...)
#   2. enables SPI (TFT), I2C + RTC overlay in /boot/firmware/config.txt
#   3. creates .venv (with system site packages) and installs requirements
#   4. builds the PuReST runner (C++)
#   5. disables the old ir-display.service (it would hold the camera)
#   6. installs + starts plr.service (always-on server) and the RTC sync timer
set -euo pipefail

REPO="$(cd "$(dirname "$0")/../.." && pwd)"
BACKEND="$REPO/backend"
RTC_MODEL="${RTC_MODEL:-ds1307}"          # ds1307 | ds3231 | none
SERVICE_USER="${SUDO_USER:-$USER}"
CONFIG=/boot/firmware/config.txt
[ -f "$CONFIG" ] || CONFIG=/boot/config.txt
REBOOT=0

say()  { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m!! %s\033[0m\n' "$*"; }

if [ "$(id -u)" -eq 0 ] && [ -z "${SUDO_USER:-}" ]; then
  warn "Run as your normal user (the script uses sudo where needed)."; exit 1
fi

say "Checking platform"
model="$(tr -d '\0' </proc/device-tree/model 2>/dev/null || echo unknown)"
echo "model: $model | $(grep PRETTY_NAME /etc/os-release | cut -d= -f2) | $(uname -m)"
case "$model" in *"Raspberry Pi 5"*) ;; *) warn "Not a Raspberry Pi 5 - the WS2812 PIO driver and pin map assume a Pi 5.";; esac

say "Installing APT packages"
sudo apt-get update
sudo apt-get install -y \
  python3-venv python3-pip python3-dev \
  python3-picamera2 python3-libcamera python3-numpy python3-simplejpeg python3-av \
  python3-lgpio python3-pil \
  ffmpeg cmake g++ pkg-config libopencv-dev \
  i2c-tools util-linux-extra rpicam-apps

say "Enabling SPI, I2C and the RTC overlay ($CONFIG)"
ensure_line() {
  if ! grep -qxF "$1" "$CONFIG"; then
    echo "$1" | sudo tee -a "$CONFIG" >/dev/null
    echo "added: $1"; REBOOT=1
  fi
}
ensure_line "dtparam=spi=on"
ensure_line "dtparam=i2c_arm=on"
if [ "$RTC_MODEL" != "none" ]; then
  ensure_line "dtoverlay=i2c-rtc,$RTC_MODEL"
fi

say "Python environment"
python3 -m venv --system-site-packages "$REPO/.venv"
PIP="$REPO/.venv/bin/pip"
"$PIP" install --upgrade pip
# luma.lcd needs the lgpio-backed RPi.GPIO shim on a Pi 5.
"$PIP" uninstall -y RPi.GPIO >/dev/null 2>&1 || true
"$PIP" install -r "$BACKEND/requirements.txt"
"$PIP" uninstall -y RPi.GPIO >/dev/null 2>&1 || true
"$PIP" install --force-reinstall --no-deps rpi-lgpio
"$PIP" install -r "$BACKEND/requirements-models.txt" || warn "ResNet runtimes not installed; PuReST still works."

say "Building PuReST (C++)"
bash "$BACKEND/scripts/build_native.sh"

say "Permissions"
sudo usermod -aG video,gpio,spi,i2c "$SERVICE_USER"
# WS2812 driver talks to /dev/pio0; let the gpio group use it.
echo 'KERNEL=="pio[0-9]*", GROUP="gpio", MODE="0660"' | sudo tee /etc/udev/rules.d/99-plr-pio.rules >/dev/null
sudo udevadm control --reload-rules && sudo udevadm trigger || true
[ -e /dev/pio0 ] || warn "/dev/pio0 is missing: update the OS (sudo apt full-upgrade) and reboot, or the LEDs cannot be driven."

say "Retiring the old ir-display.service (it would hold the camera)"
if systemctl list-unit-files | grep -q '^ir-display.service'; then
  sudo systemctl disable --now ir-display.service || true
  echo "ir-display.service disabled - the TFT is now driven by plr.service"
fi

say "Installing services"
for unit in plr.service plr-rtc.service plr-rtc.timer; do
  sed -e "s#@USER@#$SERVICE_USER#g" -e "s#@REPO@#$REPO#g" "$BACKEND/scripts/$unit" \
    | sudo tee "/etc/systemd/system/$unit" >/dev/null
done
sudo systemctl daemon-reload
sudo systemctl enable plr-rtc.timer plr.service
sudo systemctl start plr-rtc.service || true
sudo systemctl start plr-rtc.timer
if [ "$REBOOT" -eq 1 ]; then
  warn "SPI/I2C/RTC settings changed: reboot now (sudo reboot). plr.service starts automatically."
else
  sudo systemctl restart plr.service
  sleep 4
  systemctl --no-pager --lines=5 status plr.service || true
fi

IP="$(hostname -I | awk '{print $1}')"
say "Done"
echo "App server address : $IP:5000   (also shown on the TFT)"
echo "Health check       : curl http://$IP:5000/health"
echo "Live IR view       : http://$IP:5000/stream.mjpg"
echo "Logs               : journalctl -u plr.service -f"
