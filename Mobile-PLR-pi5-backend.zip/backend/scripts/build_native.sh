#!/usr/bin/env bash
# Build the PuReST runner (backend/native/purest/build/plr_purest).
# Needs: sudo apt install -y cmake g++ libopencv-dev
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$HERE/native/purest"
cmake -S "$SRC" -B "$SRC/build" -DCMAKE_BUILD_TYPE=Release
cmake --build "$SRC/build" -j"$(nproc)"
echo "built: $SRC/build/plr_purest"
"$SRC/build/plr_purest" --help >/dev/null 2>&1 || true
