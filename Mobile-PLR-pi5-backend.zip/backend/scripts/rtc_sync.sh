#!/usr/bin/env bash
# Keep the external I2C RTC (DS1307/DS3231) and the system clock in step.
# Runs as root at boot (before plr.service) and hourly via plr-rtc.timer.
#   - NTP synchronised       -> write system time into the external RTC
#   - no NTP, clock implausible (never set) -> set system time from the RTC
set -uo pipefail
dev=""
for node in /sys/class/rtc/rtc*; do
  [ -e "$node/name" ] || continue
  name=$(cat "$node/name")
  case "$name" in *rpi*) continue;; esac          # skip the Pi 5's own RTC
  dev="/dev/$(basename "$node")"; break
done
if [ -z "$dev" ]; then
  echo "plr-rtc: no external RTC found (check dtoverlay=i2c-rtc,... and i2cdetect -y 1)"
  exit 0
fi
synced=$(timedatectl show -p NTPSynchronized --value 2>/dev/null || echo no)
if [ "$synced" = "yes" ]; then
  hwclock --systohc --rtc="$dev" && echo "plr-rtc: system time (NTP) -> $dev"
elif [ "$(date +%Y)" -lt 2025 ]; then
  hwclock --hctosys --rtc="$dev" && echo "plr-rtc: $dev -> system time ($(date))"
else
  echo "plr-rtc: no NTP; system time looks valid, leaving $dev unchanged"
fi
