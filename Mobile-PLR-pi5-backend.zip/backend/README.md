# Mobile PLR backend (Raspberry Pi 5)

Python orchestrator + C++ PuReST. One always-running service owns the camera,
both WS2812 LEDs, both endstops and the TFT, and serves the app over HTTP.

## Wiring (BCM numbering)

| Part | Signal | GPIO | Header pin | Power |
|---|---|---|---|---|
| TFT GMT020-02 (ST7789) | SCL / SCLK | GPIO11 | 23 | VCC pin 1 (3.3 V), GND pin 6, wired directly |
| | SDA / MOSI | GPIO10 | 19 | |
| | RES | GPIO25 | 22 | |
| | DC | GPIO24 | 18 | |
| | CS | GPIO8 | 24 | |
| Left WS2812 | DIN | GPIO18 | 12 | 5 V bus (pin 2), GND bus |
| Right WS2812 | DIN | GPIO13 | 33 | 5 V bus, GND bus |
| Left endstop (IR emitter removed) | S | GPIO17 | 11 | **3.3 V bus**, GND bus |
| Right endstop (IR emitter removed) | S | GPIO27 | 13 | **3.3 V bus**, GND bus |
| RTC (I2C) | SDA / SCL | GPIO2 / GPIO3 | 3 / 5 | see note |
| IR camera | CSI ribbon | – | CAM/DISP port | |

Bus feeds: 3.3 V from pin 17, 5 V from pin 2, GND from pin 39 (or 9).

**Safety notes**

* The endstops' on-board resistors pull their S pin up to whatever feeds V.
  Power the endstops from **3.3 V**, or the S pin reaches 5 V and can damage
  GPIO17/27. Measure S with a multimeter (LED off and on) before connecting it.
* The WS2812s run from 5 V with 3.3 V data and no level shifter. Keep the data
  wires short (<10 cm) and put ~330 Ω in series with each DIN.
* A DS1307 needs ~5 V to work and its I2C pull-ups go to its supply. If you
  power it from 5 V, remove its pull-up resistors before connecting SDA/SCL.
  A DS3231 module runs from the 3.3 V bus without changes
  (`RTC_MODEL=ds3231` when installing).
* Pins can be changed in the settings (below); the server refuses clashes with
  the TFT, SPI0 or I2C pins.

## Install / update

```bash
cd ~/Documents/Mobile-PLR
git pull
bash backend/scripts/install_pi5.sh       # safe to re-run after every pull
```

It installs APT packages and the Python venv, enables SPI/I2C/RTC, builds
`native/purest/build/plr_purest`, disables the old `ir-display.service`
(two programs cannot share the camera), and installs `plr.service` with
`Restart=always`. Reboot once after the first install.

```bash
journalctl -u plr.service -f              # logs
sudo systemctl restart plr.service        # restart
curl http://localhost:5000/health         # everything at a glance
```

Run by hand (stop the service first): `cd backend && ../.venv/bin/python server.py`

## How a session works

1. The app sends `POST /session` (unchanged request format).
2. The encoder is attached to the already-running camera; `full_video.mp4`
   starts. Every encoded frame's libcamera **SensorTimestamp** is logged.
3. The flash schedule runs. Each WS2812 gets
   `colour × power_pct × intensity_pct × channel_gain`.
4. The endstops' edges are timestamped by the kernel. Each LED command is
   matched to its optical pulse, so `onset_s` is the **measured** light onset
   relative to the first video frame (typically ~0.2 ms after the command).
   A flash the sensor missed falls back to the command time and is flagged.
5. Recording stops; the camera keeps running (TFT and stream never pause).
6. A separate low-priority process crops both eyes and runs the selected
   analyzer; sample times come from the sensor timestamps, not nominal fps.
7. `GET /results` returns the same JSON shape the app already displays.

Files per session in `sessions/<id>/`:

| File | Contents |
|---|---|
| `full_video.mp4` | the recording |
| `frames.csv` | frame index → sensor timestamp → time_s |
| `endstop_edges.csv` | raw optical edges |
| `events.json` | flash timeline, optical latency, crosstalk, warnings |
| `pupilogram.json`, `metrics.json` | analysis (as before) |
| `pupilogram_<model>.json`, `metrics_<model>.json` | re-analyses |
| `manifest.json` | request, settings, hardware and clock status |
| `session.log` | diagnostics |

## LED power and intensity

* **power_pct** (per LED): device setting, use it to balance the eyes.
* **intensity** (per flash): from the app's slider, as before.

```bash
# make the right LED 20 % weaker to match the left one
curl -X POST -H 'Content-Type: application/json' \
     -d '{"leds": {"right": {"power_pct": 80}}}' http://<pi>:5000/settings
```

A newer app (or curl) can also send per-session values in `/session`:

```json
"leds": {"left": {"power": 80}, "right": {"power": 50, "intensity": 40}}
```

and per-flash `leftIntensity` / `rightIntensity`.

## Swapping pupil models

```bash
curl http://<pi>:5000/analyzers           # what's installed and ready
```

| Name | What |
|---|---|
| `purest` | PuReST, native C++ (default) |
| `pure` | PuRe, per-frame, no tracking |
| `resnet18` | ResNet-18 TFLite/ONNX from `ml_model/` |
| `purest_legacy` | the old `~/pupil_detection_new` binary, if present |
| `dark_blob` | example plugin |

Choose per session from the app (`pupilAnalyzer`), or force a model while
still using the old app:

```bash
curl -X POST -H 'Content-Type: application/json' \
     -d '{"analysis": {"force_analyzer": "resnet18"}}' http://<pi>:5000/settings
# back to the app's choice:
curl -X POST -H 'Content-Type: application/json' \
     -d '{"analysis": {"force_analyzer": null}}' http://<pi>:5000/settings
```

Compare models on a recording you already have:

```bash
curl -X POST -H 'Content-Type: application/json' -d '{"analyzer": "resnet18"}' \
     http://<pi>:5000/sessions/<session_id>/reanalyze
curl "http://<pi>:5000/sessions/<session_id>/results?analyzer=resnet18"
```

Add a new model:

* **Python:** copy `plr/analyzers/plugins/example_threshold.py`, implement
  `analyze(video_path) -> DataFrame[frame, diameter_px, confidence, valid]`,
  restart the service.
* **Any program / other venv:** register it in the settings:

```json
{"analysis": {"commands": {"my_model": {
  "cmd": ["/home/pi/torch-venv/bin/python", "/home/pi/my_model.py", "{input}", "{output}"],
  "description": "my model"}}}}
```

The program reads the eye video `{input}` and writes a CSV `{output}` with
`frame,diameter_px,confidence,valid`.

If PuReST ever locks onto the iris on your images, narrow its size assumption:
`{"analysis": {"purest": {"max_pupil_mm": 8}}}`.

## Checking the hardware

```bash
curl -X POST http://<pi>:5000/selftest              # flashes each LED 5x
curl -X POST -H 'Content-Type: application/json' \
     -d '{"side": "left", "hex": "#FFFFFF", "intensity": 30, "duration": 0.2}' \
     http://<pi>:5000/leds/test
curl http://<pi>:5000/time                          # NTP / RTC status
```

`/selftest` should report `5/5` detections per side, ~0.1–1 ms latency and
no crosstalk. If a sensor reads "active with LEDs off", ambient light reaches
it or its polarity is wrong (`endstops.left.active`: `auto`/`low`/`high`).

Live IR view in a browser: `http://<pi>:5000/stream.mjpg`.

## Settings reference

`GET /settings` shows everything; `POST /settings` merges a partial update
into `device_settings.json` (repo root, git-ignored). LED and analysis
changes apply immediately; camera, endstop and display changes need
`POST /restart`. Main keys:

* `leds.left|right`: `gpio`, `power_pct`, `enabled`, `pixel_count`, `color_order`, `channel_gain`
* `endstops`: `left|right.gpio/active/enabled`, `bias`, `merge_gap_us`, `max_latency_ms`, `require_optical`
* `camera`: `index`, `resolution`, `fps`, `lores`, `bitrate`, `controls` (e.g. fixed exposure), `hflip`, `vflip`
* `display`: SPI/DC/RST pins, `rotate`, `fps`, `overlay`
* `analysis`: `default_analyzer`, `force_analyzer`, `confidence_threshold`, `cpus`, `nice`, `purest`, `commands`
* `eye_crop`: `mode` (`detect`/`static`), `left_roi`, `right_roi`, `output_size`
* `session`: `pre_roll_s`, `post_roll_s`, `min_gap_s`, `window_pre_s`, `window_post_s`, `keep_eye_crops`

## Testing without hardware

```bash
cd backend
python -m pytest tests -q                       # unit tests
PLR_HARDWARE=mock python server.py              # simulated camera/LEDs/endstops
```

Mock mode renders two synthetic IR eyes whose pupils react to the simulated
LEDs, so the full app → recording → PuReST → results path can be exercised on
a laptop (set `eye_crop.mode` to `static` for the synthetic eyes).

## Troubleshooting

| Symptom | Check |
|---|---|
| `leds.ready=false`, "/dev/pio0" | `sudo apt full-upgrade && sudo reboot`; `ls -l /dev/pio0` |
| camera `running=false` | `rpicam-hello --list-cameras`; is `ir-display.service` still enabled? |
| TFT blank | `ls /dev/spidev0.0`; `display.error` in `/health`; `display.rotate` |
| flashes "not seen by the endstops" | `/selftest`; sensor alignment; 3.3 V supply; low intensity may be below the sensor threshold |
| analyzer not ready | `/analyzers`; `bash backend/scripts/build_native.sh` |
| clock wrong without network | `/time`; `i2cdetect -y 1` shows 0x68; `dtoverlay=i2c-rtc,...` in config.txt |
