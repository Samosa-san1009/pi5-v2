# Mobile PLR – Raspberry Pi 5

Pupillary light reflex (PLR) rig: a Raspberry Pi 5 flashes a WS2812 LED into
each eye, measures the true moment of every flash with modified optical
endstops, records the eyes with an always-on IR camera (shown live on a small
TFT), and computes the pupil response with PuReST or another model. The
existing Eyezer phone app starts sessions and shows the results.

* What every file does: [`docs/FILE_STRUCTURE.md`](docs/FILE_STRUCTURE.md)
* Backend reference (API, settings, models): [`backend/README.md`](backend/README.md)
* Testing: [`TESTING.md`](TESTING.md)

**Follow the steps in order.** Steps 1–8 are a one-time setup. After that,
only "Daily use" and "Updating" matter.

| Step | Where | What |
|---|---|---|
| 1 | PC | Put the new code on GitHub |
| 2 | Pi | Update Raspberry Pi OS and check the platform |
| 3 | Pi | Turn off the old IR display (`ir-display.service`) |
| 4 | Pi (powered off) | Wire and safety-check the hardware |
| 5 | Pi | Get the code onto the Pi |
| 6 | Pi | Run the installer |
| 7 | Pi | Reboot |
| 8 | Pi / PC | Verify everything works |
| 9 | Pi | Optional: balance LEDs, camera, RTC |
| 10 | Phone | Run a session from the app |

---

## What you need

* Raspberry Pi 5 with 64-bit Raspberry Pi OS **Bookworm**, network access, SSH or a keyboard/monitor
* IR camera on the CSI port
* GMT020-02 2.0" ST7789 TFT (7-pin SPI)
* 2 × WS2812 LEDs (left and right eye), each on its own data wire
* 2 × optical endstops with the IR emitter removed, one facing each LED
* RTC module on I2C (DS1307 "Tiny RTC" or DS3231) with a CR2032 cell
* A perfboard power bus (3.3 V, 5 V, GND), a multimeter
* The Eyezer app on a phone on the same network as the Pi
* A PC with `git` (only for step 1)

---

## Step 1 – Put the new code on GitHub (PC, once)

You received `0001-pi5-orchestrator.patch`. Apply it to your fork and push,
so the Pi can simply `git pull`.

```bash
git clone https://github.com/Samosa-san1009/Mobile-PLR.git
cd Mobile-PLR
git am /path/to/0001-pi5-orchestrator.patch
git log --oneline -2          # top line: "Pi 5 orchestrator: ..."
git push
```

If `git am` complains about your identity, run
`git config user.name "Your Name"` and `git config user.email "you@example.com"`
and try again. If it reports a conflict, run `git am --abort` and make sure
your fork is at commit `a8190e4` ("Delete backend/__pycache__/...").

*No GitHub access?* Unzip `Mobile-PLR-pi5-backend.zip` over a copy of the
repository instead (it contains `backend/`, `README.md`, `.gitignore`).

---

## Step 2 – Update the Pi and check the platform (Pi)

```bash
sudo apt update && sudo apt full-upgrade -y
sudo reboot
```

After it comes back:

```bash
cat /proc/device-tree/model; echo     # must say: Raspberry Pi 5 Model B
grep PRETTY_NAME /etc/os-release      # Debian GNU/Linux 12 (bookworm)
uname -m                              # aarch64
ls -l /dev/pio0                       # must exist (WS2812 driver needs it)
rpicam-hello --list-cameras           # your IR camera must be listed
```

If `/dev/pio0` is missing, the OS is too old: repeat the full-upgrade and
reboot. Note which camera number your IR camera has (usually `0`); you'll
need it in step 9 only if more than one camera is listed.

---

## Step 3 – Turn off the old IR display (Pi)

The old `ir_display.py` from the led-test repo opens the camera itself. A
camera can only be opened by one program, so while it runs the PLR server
cannot record. Its job (live picture on the TFT) is now done by the PLR
server. The installer in step 6 also disables it, but do it by hand now so
you can confirm the camera is free.

### 3a. Is it running?

```bash
systemctl status ir-display.service --no-pager
```

* `Active: active (running)` → continue with 3b.
* `Unit ir-display.service could not be found` → it was never installed as a
  service; skip to 3c.

### 3b. Stop it and stop it from starting at boot

```bash
sudo systemctl stop ir-display.service       # stops it now
sudo systemctl disable ir-display.service    # stops it starting at boot
systemctl is-enabled ir-display.service      # should print: disabled
systemctl is-active ir-display.service       # should print: inactive
```

Optional – remove it completely (you can restore it from the led-test repo):

```bash
sudo rm /etc/systemd/system/ir-display.service
sudo systemctl daemon-reload
```

### 3c. Make sure nothing else is holding the camera

```bash
pgrep -af "ir_display|rpicam|libcamera-|picamera"   # should print nothing
```

If something is listed, stop it: `sudo pkill -f ir_display.py` (and close
any `rpicam-hello` window). Also check it isn't started another way:

```bash
crontab -l 2>/dev/null | grep -i ir_display
sudo crontab -l 2>/dev/null | grep -i ir_display
grep -i ir_display /etc/rc.local 2>/dev/null
ls ~/.config/autostart 2>/dev/null
```

Remove any line or autostart entry that launches `ir_display.py`.

### 3d. Confirm the camera is free

```bash
rpicam-hello -t 2000          # a 2-second preview must open without "busy" errors
```

On a headless Pi, use `rpicam-still -o /tmp/test.jpg` instead. It must
succeed.

### 3e. Old pigpio daemon (optional)

The previous version used `pigpiod`, which does not support the Pi 5. It is
not needed any more:

```bash
sudo systemctl disable --now pigpiod 2>/dev/null || true
```

*To bring the old display back later:* `sudo systemctl stop plr.service`,
then `sudo systemctl enable --now ir-display.service`. Never run both at
once.

---

## Step 4 – Wire and check the hardware (Pi powered OFF)

Shut down first: `sudo poweroff`, then unplug the power.

| Part | Pin on part | Pi GPIO (BCM) | Physical pin | Power |
|---|---|---|---|---|
| TFT | VCC | – | 1 (3.3 V) | wired straight to the Pi, not the bus |
| TFT | GND | – | 6 | |
| TFT | SCL | GPIO11 | 23 | |
| TFT | SDA | GPIO10 | 19 | |
| TFT | RES | GPIO25 | 22 | |
| TFT | DC | GPIO24 | 18 | |
| TFT | CS | GPIO8 | 24 | |
| Left WS2812 | DIN | GPIO18 | 12 | 5 V bus, GND bus |
| Right WS2812 | DIN | GPIO13 | 33 | 5 V bus, GND bus |
| Left endstop | S | GPIO17 | 11 | 3.3 V bus, GND bus |
| Right endstop | S | GPIO27 | 13 | 3.3 V bus, GND bus |
| RTC | SDA | GPIO2 | 3 | see below |
| RTC | SCL | GPIO3 | 5 | |
| Bus feed | 3.3 V | – | 17 | → 3.3 V bus |
| Bus feed | 5 V | – | 2 | → 5 V bus |
| Bus feed | GND | – | 39 (or 9) | → GND bus |

Checks before powering on (multimeter, everything unplugged from the Pi):

1. **No shorts:** continuity between the 3.3 V, 5 V and GND bus rails must be
   open in every combination.
2. **Endstops on 3.3 V only.** The endstop board pulls its S pin up to its V
   supply; on 5 V it would put 5 V on GPIO17/27 and can damage the Pi.
3. **First power-up with S disconnected:** power the Pi, measure each S pin
   to GND with the LED off and with a torch shining in. It must stay between
   0 and 3.3 V. Then power off and connect S to GPIO17/27.
4. **WS2812 data wires short** (under ~10 cm); ideally a 330 Ω resistor in
   series with each DIN.
5. **RTC:** a DS1307 needs about 5 V and its pull-up resistors go to its
   supply. On 5 V, remove its SDA/SCL pull-ups first; on 3.3 V it won't work
   reliably. A DS3231 runs on the 3.3 V bus as is. If the Tiny RTC board has
   a charging circuit and you use a non-rechargeable CR2032, remove the
   charging diode/resistor.

---

## Step 5 – Get the code onto the Pi

**Fresh copy:**

```bash
mkdir -p ~/Documents && cd ~/Documents
git clone https://github.com/Samosa-san1009/Mobile-PLR.git
cd Mobile-PLR
```

**Already have the old fork there:**

```bash
cd ~/Documents/Mobile-PLR
git status                     # any local changes?
git stash                      # only if it listed changes you want to keep aside
git pull
rm -rf .venv                   # clean environment (old one had pigpio etc.)
```

Check you have the new version:

```bash
ls backend/plr backend/scripts     # must exist
```

---

## Step 6 – Run the installer

Run as your normal user (not with sudo – it asks for your password when
needed). Pick the line that matches your RTC:

```bash
cd ~/Documents/Mobile-PLR
bash backend/scripts/install_pi5.sh                     # DS1307 (default)
RTC_MODEL=ds3231 bash backend/scripts/install_pi5.sh    # DS3231
RTC_MODEL=none   bash backend/scripts/install_pi5.sh    # no external RTC
```

It takes 5–15 minutes and performs, in order:

1. Installs APT packages (camera, lgpio, OpenCV dev, ffmpeg, cmake, i2c-tools…)
2. Adds `dtparam=spi=on`, `dtparam=i2c_arm=on`, `dtoverlay=i2c-rtc,<model>` to `/boot/firmware/config.txt`
3. Creates `.venv` and installs the Python packages
4. Builds the PuReST C++ runner (`backend/native/purest/build/plr_purest`)
5. Adds your user to the `video gpio spi i2c` groups and allows access to `/dev/pio0`
6. Disables `ir-display.service` if it still exists
7. Installs and enables `plr.service` (the server) and `plr-rtc.timer`

It must end with `== Done`. If it stops with an error, fix that (the
message names the failing step) and run the same command again; it is safe
to re-run.

---

## Step 7 – Reboot

```bash
sudo reboot
```

Needed once, so SPI, I2C and the RTC overlay take effect. After the reboot
`plr.service` starts by itself: the camera opens and the TFT shows the live
IR picture with the Pi's IP address at the bottom.

---

## Step 8 – Verify

Run these on the Pi (or replace `localhost` with the Pi's IP from a PC).

**8a. Service running**

```bash
systemctl status plr.service --no-pager      # Active: active (running)
journalctl -u plr.service -n 30 --no-pager   # "listening on 0.0.0.0:5000"
```

**8b. Health**

```bash
curl -s localhost:5000/health | python3 -m json.tool | less
```

Look for:

| Field | Expected |
|---|---|
| `ok` | `true` |
| `hardware.camera.running` | `true`, `measured_fps` ≈ 30 |
| `hardware.leds.ready` | `true`, `backend`: `pi5_pio` |
| `hardware.endstops.ready` | `true`, `timestamp_clock`: `monotonic` (after the first flash) |
| `hardware.display.running` | `true` |
| `analyzers.purest.ready` | `true` |
| `hardware.clock.wall_clock_source` | `ntp` or `rtc` |

**8c. LEDs + endstops self-test** (each LED flashes 5 times)

```bash
curl -s -X POST localhost:5000/selftest | python3 -m json.tool
```

Expected: `"ok": true`, each side `"detected": "5/5"`, latency around
0.1–1 ms, `crosstalk_trials: 0`. If the left LED lights but `detected` is
0/5, the left sensor isn't seeing it (alignment, wiring, 3.3 V supply).

**8d. Live camera in a browser (PC/phone):** `http://<pi-ip>:5000/stream.mjpg`

**8e. Clock / RTC:**

```bash
curl -s localhost:5000/time | python3 -m json.tool
sudo i2cdetect -y 1        # RTC at 0x68 (shows "UU" once the kernel driver owns it)
```

Brand-new RTC: once the Pi has internet time, write it into the RTC with
`sudo systemctl start plr-rtc.service`.

---

## Step 9 – Optional adjustments

All settings are changed over HTTP and saved in `device_settings.json`
(survives reboots and `git pull`). See them all: `curl localhost:5000/settings`.

**Balance the two LEDs** (e.g. right LED looks brighter):

```bash
curl -X POST -H 'Content-Type: application/json' \
  -d '{"leds": {"right": {"power_pct": 80}}}' localhost:5000/settings
```

Applies immediately. Test one LED at a given brightness:

```bash
curl -X POST -H 'Content-Type: application/json' \
  -d '{"side": "right", "hex": "#FFFFFF", "intensity": 50, "duration": 0.5}' localhost:5000/leds/test
```

**Choose the camera** (only if `rpicam-hello --list-cameras` lists more than one):

```bash
curl -X POST -H 'Content-Type: application/json' -d '{"camera": {"index": 1}}' localhost:5000/settings
curl -X POST localhost:5000/restart
```

**Fixed IR exposure** (stops auto-exposure drifting during a session):

```bash
curl -X POST -H 'Content-Type: application/json' \
  -d '{"camera": {"controls": {"AeEnable": false, "ExposureTime": 10000, "AnalogueGain": 4.0}}}' localhost:5000/settings
curl -X POST localhost:5000/restart
```

**TFT picture sideways/upside down:** set `display.rotate` to 0–3, then restart.

---

## Step 10 – Run a session from the app

1. Phone on the same Wi-Fi as the Pi.
2. In the app's configuration screen, type the address shown on the TFT, e.g. `10.2.130.167:5000`.
3. Choose the mode, colours, durations, intensity and pupil model (PuReST) as before, and start.
4. The TFT shows `RECORDING` with a red REC dot, then `ANALYSIS`, then `DONE`; the app opens the results.

Stop a running session early: `curl -X POST <pi-ip>:5000/session/stop`.

---

## Daily use

| Task | Command |
|---|---|
| Is everything OK? | `curl -s <pi-ip>:5000/health` |
| Live picture | browser → `http://<pi-ip>:5000/stream.mjpg` |
| Watch logs | `journalctl -u plr.service -f` |
| Restart the server | `sudo systemctl restart plr.service` |
| Stop the server (e.g. to run `tools/flash_timer.py`) | `sudo systemctl stop plr.service` |
| List sessions | `curl -s <pi-ip>:5000/sessions` |
| Copy all sessions to a PC | `scp -r <user>@<pi-ip>:~/Documents/Mobile-PLR/sessions ./` |
| Re-analyse a session with another model | `curl -X POST -H 'Content-Type: application/json' -d '{"analyzer":"resnet18"}' <pi-ip>:5000/sessions/<id>/reanalyze` |
| Force a model while using the old app | `curl -X POST -H 'Content-Type: application/json' -d '{"analysis":{"force_analyzer":"resnet18"}}' <pi-ip>:5000/settings` |
| Back to the app's model choice | same with `"force_analyzer": null` |
| Which models are ready | `curl -s <pi-ip>:5000/analyzers` |

Each session is saved in `~/Documents/Mobile-PLR/sessions/<date_time_name>/`
(video, per-frame timestamps, flash timeline, pupilogram, metrics, log).

---

## Updating later

```bash
cd ~/Documents/Mobile-PLR
git pull
bash backend/scripts/install_pi5.sh      # same RTC_MODEL as before
```

Your settings and sessions are kept (they are not tracked by git). Reboot
only if the installer says so.

---

## Troubleshooting

| Problem | What to check |
|---|---|
| `camera.running` false | Step 3 again (old display still holding the camera?); `rpicam-hello --list-cameras`; ribbon cable; `journalctl -u plr.service` |
| `leds.ready` false, mentions `/dev/pio0` | `sudo apt full-upgrade && sudo reboot`; `ls -l /dev/pio0` |
| TFT stays black | `ls /dev/spidev0.0` (SPI enabled? reboot done?); `display.error` in `/health`; wiring of DC/RES/CS |
| Self-test `0/5` on one side | LED lights? Sensor facing it? Sensor on 3.3 V? `idle_warnings` in the self-test output |
| "flash(es) were not seen by the endstops" | Low intensity can be below the sensor threshold; run `/leds/test` at that intensity |
| `analyzer 'purest' is not ready` | `bash backend/scripts/build_native.sh` |
| `resnet18` not ready | `.venv/bin/pip install -r backend/requirements-models.txt`; see `/analyzers` for the exact error |
| App says it can't reach the Pi | Same network? Address includes `:5000`? `curl <pi-ip>:5000/health` from another device |
| Wrong date without internet | `/time`; `sudo i2cdetect -y 1`; RTC battery; `dtoverlay=i2c-rtc,...` in `/boot/firmware/config.txt` |

More detail: [`backend/README.md`](backend/README.md).

---

## Licence note

PuRe/PuReST (`backend/native/purest/third_party`) are © Thiago Santini et al.
and licensed for **non-commercial use only**. Keep the licence files and cite
the PuReST paper (Santini, Fuhl, Kasneci, ETRA 2018) in publications.
