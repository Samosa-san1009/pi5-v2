# Testing

## 1. Unit tests (any PC, no hardware)

```bash
cd Mobile-PLR/backend
python3 -m pip install pytest numpy pandas opencv-python-headless flask
python3 -m pytest tests -q          # expect: 21 passed
```

Covers settings validation and pin clashes, all app request formats, the LED
brightness formula, WS2812 byte order, PWM burst merging, optical-vs-command
flash matching, and metrics with dropped frames.

## 2. Full pipeline with simulated hardware (any Linux PC)

Needs the PuReST runner built first (`bash backend/scripts/build_native.sh`,
requires `cmake g++ libopencv-dev`).

```bash
cd Mobile-PLR/backend
echo '{"eye_crop": {"mode": "static"}}' > /tmp/plr_settings.json
PLR_HARDWARE=mock PLR_SETTINGS_PATH=/tmp/plr_settings.json \
PLR_SESSIONS_ROOT=/tmp/plr_sessions python3 server.py
```

Then point the app (or curl) at the PC's IP on port 5000. A synthetic
two-eye IR video is rendered whose pupils react to the simulated LEDs about
220 ms after each flash, so the whole app → recording → PuReST → results path
can be checked. `static` crop mode is needed because the eye detector does
not recognise the cartoon eyes.

## 3. On the rig

In this order (see README step 8):

1. `curl <pi-ip>:5000/health` – camera, LEDs, endstops, display, analyzers ready
2. `curl -X POST <pi-ip>:5000/selftest` – 5/5 optical detections per side, no crosstalk
3. `http://<pi-ip>:5000/stream.mjpg` – both eyes visible and in focus
4. A short dual session from the app – check `sessions/<id>/events.json`:
   every event has `"timestamp_source": "endstop_optical"`
5. Re-analyse that session with another model and compare:
   `POST /sessions/<id>/reanalyze {"analyzer": "pure"}`

Stand-alone endstop check without the server:

```bash
sudo systemctl stop plr.service
.venv/bin/python backend/tools/flash_timer.py --gpio 17 --active-low --pull up
sudo systemctl start plr.service
```
